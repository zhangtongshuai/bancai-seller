require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','area','slider','base'], function($,template,md5,layui,cookie,area) {

		/**
		 * 数据渲染
		 */
		//获取用户信息
		var jhbCookie = $.cookie(),
			access_token = jhbCookie.access_token,
			user_id = jhbCookie.user_id;
		
		var shop_id = $.cookie('shop_id');
		if(shop_id == 0){
			layer.alert('您没有开通店铺', {'title': false,'closeBtn': 0}, function(){
				window.location.href = 'seller-shop.html';
			});
		}
		/**
		 * 交互效果
		 */
		//banner
		getMsg('shopinfo_banner', '.buyer-right-bottom.product-zhan1.ad', 3, '.updata-box.one');
		//店铺上传banner图片
		upServerPic('.buyer-right-bottom.product-zhan1.ad #product-zhan-up', '.buyer-right-bottom.product-zhan1.ad', 3, '.updata-box.one', 2*1024, '2M');
		//点击叉号去除图片
		$('.buyer-right-bottom.product-zhan1.ad ul').on('click', 'i', function(event) {
			$(this).parents('li.picc').remove();
			var picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
			if(picLiLen <= 3) {
				$('.updata-box.one').show();
			}
			//取消事件冒泡
			event.stopPropagation();
		});
		//点击banner图片下的保存按钮
		$('#shop-banner').on('click', function(){
			saveServerPic('.buyer-right-bottom.product-zhan1.ad', 'banner图没有上传', 'shopinfo_banner');
		});
		
		
		//企业资质
		getMsg('shopinfo_qualifications', '.buyer-right-bottom.product-zhan1.zi', 10, '.updata-box.two');
		//企业资质图片的上传
		upServerPic('.buyer-right-bottom.product-zhan1.zi #product-zizhi-up', '.buyer-right-bottom.product-zhan1.zi', 10, '.updata-box.two', 2*1024, '2M');
		//点击叉号去除图片
		$('.buyer-right-bottom.product-zhan1.zi ul').on('click', 'i', function(event) {
			$(this).parents('li.picc').remove();
			var picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
			if(picLiLen <= 10) {
				$('.updata-box.two').show();
			}
			//取消事件冒泡
			event.stopPropagation();
		});
		//点击资质保存按钮
		$('#zizhi-pic').on('click', function(){
			saveServerPic('.buyer-right-bottom.product-zhan1.zi', '企业资质图没有上传', 'shopinfo_qualifications');
		});
		
		
		//企业展示
		getMsg('shopinfo_display', '.buyer-right-bottom.product-zhan1.zhan-shi', 10, '.updata-box.three');
		//企业展示图片的上传
		upServerPic('.buyer-right-bottom.product-zhan1.zhan-shi #product-zhan-pic', '.buyer-right-bottom.product-zhan1.zhan-shi', 10, '.updata-box.three', 2*1024, '2M');
		//点击叉号去除图片
		$('.buyer-right-bottom.product-zhan1.zhan-shi ul').on('click', 'i', function(event) {
			$(this).parents('li.picc').remove();
			var picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
			if(picLiLen <= 10) {
				$('.updata-box.three').show();
			}
			//取消事件冒泡
			event.stopPropagation();
		});
		//点击展示保存按钮
		$('#zhanshi-pic').on('click', function(){
			saveServerPic('.buyer-right-bottom.product-zhan1.zhan-shi', '企业展示图没有上传', 'shopinfo_display');
		});
		
		
		//获取企业简介信息
		$.ajax({
			type: "get",
			url: api+"/api/shopinfo_profile?access_token="+access_token+"&user_id="+user_id,
			async: true,
			dataType: 'json'
		}).then(function(jianjieData){
			if(jianjieData.err_code != 0){
				layer.alert(jianjieData.msg, {'title': false,'closeBtn': 0});
				return false;
			}
			
			if ('' != jianjieData.data.profile) {
				$('.buyer-right-bottom.product-zhan1.jie-shao textarea').val(jianjieData.data.profile);
				$('.buyer-right-bottom.product-zhan1.jie-shao p').html('当前已输入'+($('.buyer-right-bottom.product-zhan1.jie-shao textarea').val().length)+'个字符，您还能输入'+(1000 - $('.buyer-right-bottom.product-zhan1.jie-shao textarea').val().length)+'个字符');
			}
		});
		//企业简介保存
		$('#jieshao-text').on('click', function(){
			var comJianJie = $('.buyer-right-bottom.product-zhan1.jie-shao textarea').val();
			if ('' == comJianJie) {
				layer.alert('企业介绍没有填写', {'title': false,'closeBtn': 0});
				return false;
			}
			var jieshaoObj = {
				user_id: user_id,
				access_token: access_token,
				profile: comJianJie
			};
			console.log(JSON.stringify(jieshaoObj));
			$.ajax({
				type: "post",
				url: api+"/api/shopinfo_profile?access_token="+access_token+"&user_id="+user_id,
				async: true,
				data: JSON.stringify(jieshaoObj),
				dataType: 'json'
			}).then(function(zhanshiData){
				//console.log(zhanshiData);
				if (zhanshiData.err_code == 0) {					
					layer.alert('保存成功', {'title': false,'closeBtn': 0});
				}else{
					layer.alert(zhanshiData.msg, {'title': false,'closeBtn': 0});
				}
			});
		});
		
		
		/**
		 * 图片展示方法
		 * @param {String} eleChange 图片上传点击的元素input
		 * @param {String} ele 图片展示插入的元素
		 * @param {Number} num 上传元素隐藏的图片总数
		 * @param {String} upEle 上传元素
		 */
		function upServerPic(eleChange, ele, num, upEle, picSizeNum, picAlertMsg){
			var picLiLen = 0,
				piccI = 0, //图片的顺序标示
				pictureFile; //图片base64信息
			$(eleChange).on('change', function(event) {
				//获取图片的大小
				var fileSize = this.files[0].size;
				//图片顺序改变
				piccI ++;
				//对于图片的大小进行比较
				if(fileSize > picSizeNum * 1024) {
					layer.alert("上传图片大小不能超过"+picAlertMsg, {'title': false,'closeBtn': 0});
					return false;
				} else {
					var file = $(this)[0].files[0];
					if(!/image\/\w+/.test(file.type)){   
						alert("请确保文件为图像类型"); 
						return false; 
					}
					r = new FileReader();  //本地预览
					r.onload = function(){
						pictureFile  = r.result;
						$(ele + ' ul').prepend('<li class="picc picc'+piccI+'">' +
							'<div class="layui-progress"><div class="layui-progress-bar" lay-percent="0%"></div></div>'
																		+ '</li>');
						
						//上传图片时加载进度
						var oldProgressNum = [0, 0, 0, 0, 0, 0];//进度初始化的数
						var timerProgress = setInterval(function(){
							var progressNum = Math.ceil(Math.random()*3);
							oldProgressNum[piccI] += progressNum;
							if (oldProgressNum[piccI] >= 85) {
								clearInterval(timerProgress);
								$(ele + ' ul li.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
								$(ele + ' ul li.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
								return false;
							}
							$(ele + ' ul li.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
							$(ele + ' ul li.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
						}, 100);
						
						//没有上传完之前input隐藏
						$(this).hide();
						var product_commit_obj = {
							user_id: user_id,
							access_token: access_token,
							simage: pictureFile
						};
						
						$.ajax({
							type: "post",
							url: api+"/api/Upload_Image",
							async:true,
							data: JSON.stringify(product_commit_obj),
							dataType: 'json'
						}).then(function(picUploadData){
							if(picUploadData.err_code == 0){
								$(this).show();
								$(ele + ' ul li.picc' + piccI).empty();
								$(ele + ' ul li.picc' + piccI).append('<img src="'+picUploadData.data.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div>');
							}else{
								layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});
							}
						});
						
						
						picLiLen = $(ele + ' ul li.picc').length;
						if(picLiLen == num) {
							$(upEle).hide();
						}
					}
					r.readAsDataURL(file);    //Base64
					
//					var imageUrl = getObjectURL($(this)[0].files[0]);
//					var index = $(this)[0].files[0].name.lastIndexOf('.');
//					var imagethis = $(this)[0].files[0].name.slice(index+1);
//					if(imagethis == 'jpg'){
//						imagethis = 'jpeg';
//					}
//					convertImgToBase64(imageUrl, function(base64Img) {
//						pictureFile = base64Img;
//						
//						$(ele + ' ul').prepend('<li class="picc picc'+piccI+'">' +
//							'<div class="layui-progress"><div class="layui-progress-bar" lay-percent="0%"></div></div>'
//																		+ '</li>');
//						
//						//上传图片时加载进度
//						var oldProgressNum = [0, 0, 0, 0, 0, 0];//进度初始化的数
//						var timerProgress = setInterval(function(){
//							var progressNum = Math.ceil(Math.random()*3);
//							oldProgressNum[piccI] += progressNum;
//							if (oldProgressNum[piccI] >= 85) {
//								clearInterval(timerProgress);
//								$(ele + ' ul li.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
//								$(ele + ' ul li.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
//								return false;
//							}
//							$(ele + ' ul li.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
//							$(ele + ' ul li.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
//						}, 100);
//						
//						//没有上传完之前input隐藏
//						$(this).hide();
//						var product_commit_obj = {
//							user_id: user_id,
//							access_token: access_token,
//							simage: pictureFile
//						};
//						
//						$.ajax({
//							type: "post",
//							url: api+"/api/Upload_Image",
//							async:true,
//							data: JSON.stringify(product_commit_obj),
//							dataType: 'json'
//						}).then(function(picUploadData){
//							if(picUploadData.err_code == 0){
//								$(this).show();
//								$(ele + ' ul li.picc' + piccI).empty();
//								$(ele + ' ul li.picc' + piccI).append('<img src="'+picUploadData.data.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div>');
//							}else{
//								layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});
//							}
//						});
//						
//						
//						picLiLen = $(ele + ' ul li.picc').length;
//						if(picLiLen == num) {
//							$(upEle).hide();
//						}
//					}, 'image/'+imagethis);
//					
//					event.preventDefault();
				}
			});
		}
		//上传图片的方法
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 1;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}
		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		}
		/**
		 * 获取图片上传的信息
		 * @param {String} apiLink 网络请求的具体接口
		 * @param {String} ele 图片展示插入的元素
		 * @param {Number} num 上传图片的元素隐藏，信息中的图片长度
		 * @param {String} upEle 上传图片的元素
		 */
		function getMsg(apiLink, ele, num, upEle){
			$.ajax({
				type: "get",
				url: api+"/api/"+apiLink+"?access_token="+access_token+"&user_id="+user_id,
				async:true,
				dataType: 'json'
			}).then(function(shopbannerData){
				if(shopbannerData.err_code != 0){
					layer.alert(shopbannerData.msg, {'title': false,'closeBtn': 0});
					return false;
				}
				if (shopbannerData.data.length != 0) {
					$.each(shopbannerData.data, function(key, value) {
						$(ele + ' ul').prepend('<li class="picc">' +
							'<img src="'+value.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div>'
																		+ '</li>');
					});
					if (shopbannerData.data.length == num) {
						$(upEle).hide();
					}
				}
			});
		}
		/**
		 * 点击保存按钮的方法
		 * @param {String} ele 图片展示插入的元素
		 * @param {String} alertMsg 空的提示信息
		 * @param {String} apiLink 网络请求的具体接口
		 */
		function saveServerPic(ele, alertMsg, apiLink){
			var bannerPicArr = [];
			var picLiLen = $(ele + ' ul li.picc').length;
			if (picLiLen == 0) {
				layer.alert(alertMsg, {'title': false,'closeBtn': 0});
				return false;
			}
			for (let i=0; i<picLiLen; i++) {
			    bannerPicArr.push({"image_url": $(ele + ' ul li.picc').eq(i).find('img').attr('src')});
			}
			
			var bannerObj = {image_list: bannerPicArr};
			
			$.ajax({
				type: "post",
				url: api+"/api/"+apiLink+"?access_token="+access_token+"&user_id="+user_id,
				async: true,
				data: JSON.stringify(bannerObj),
				dataType: 'json'
			}).then(function(bannerData){
				//console.log(bannerData);
				if (bannerData.err_code == 0) {					
					layer.alert('保存成功', {'title': false,'closeBtn': 0});
				}else{
					layer.alert(bannerData.msg, {'title': false,'closeBtn': 0});
				}
			});
		}
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(6).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
		
		//点击后大图展示
		$('.buyer-right-bottom.product-zhan1 ul').on('click', 'li.picc', function(){
			$('.big-pic').find('img').attr('src', $(this).find('img').attr('src'));
			$('.big-pic').css({'display': 'block'});
		});
		$('.big-pic').on('click', function(){
			$(this).hide();
		});
		
		//文本域右下角的字符统计
		$('.buyer-right-bottom.product-zhan1.jie-shao textarea').on('input propertychange', function(){
			$('.buyer-right-bottom.product-zhan1.jie-shao p').html('当前已输入'+($(this).val().length)+'个字符，您还能输入'+(1000 - $(this).val().length)+'个字符');
		});
	});
});