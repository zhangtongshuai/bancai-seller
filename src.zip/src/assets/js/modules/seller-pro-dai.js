require(['../common/common'], function(c) {
	require(['jquery','template','layui','cookie','base','pager'], function($,template) {

		/**
		 * 数据渲染
		 */
		var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		//进入页面时获得的数据
		//init
	    $(function () {
	        searchFilter(1)
	    });
	    
		function searchFilter(pageindex){
			var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
	        }
            
			$.ajax({
				url: api+"/api/product?access_token="+access_token+"&user_id="+user_id+"&status=1&page_no="+pageNo,
				type: 'get',
				dataType: 'json',
				success:function(result){
					//console.log(result);
					if (result.err_code != 0) {
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
						return false;
					}
					var count = parseInt(result.data.record_count);
                    var totalPage = parseInt(result.data.page_total);
                    if (count == 0) {
                    	$('table').after('<p>没有数据</p>');
                    }else{
                    	var data = result.data.list;
	                    var html = template('protemplate', data);
						$('table tbody').html(html);
						//生成分页
						kkpager.generPageHtml({
							pno: pageNo,
							//总页码
							total : totalPage,
							//总数据条数
							totalRecords : count,
							mode : 'click',
							click : function(n){
							    this.selectPage(pageNo);
			                    searchPage(n);
			                    return false;
							}
						},true);
                    }
					$('.buyer-right-bottom table td').on('click', 'a:eq(0)', function(){
						if ($(this).hasClass('layui-btn-disabled')) {
							return false;
						}
						var prosku = $(this).parents('tr').data();
						$.cookie('catagory', prosku.catagory);
						$.cookie('pname', prosku.pname);
						$.cookie('sku_id', prosku.skuid);
						$.cookie('different', 1);
						switch(prosku.catagory){
							case '胶合板':
								window.location.href = 'seller-publish-jhb.html';
								break;
							case '面底板':
								window.location.href = 'seller-publish-mdib.html';
								break;
							case '刨花板':
								window.location.href = 'seller-publish-bhb.html';
								break;
							case '单板':
								window.location.href = 'seller-publish-db.html';
								break;
							case '密度板':
								window.location.href = 'seller-publish-mdb.html';
								break;
							case '实木板':
								window.location.href = 'seller-publish-smb.html';
								break;
						}
					});
				},
				error: function () {
                    layer.msg('网络请求失败，请刷新后重试！');
                }	
			})
		}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
		/**
		 * 交互效果
		 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
	});
});