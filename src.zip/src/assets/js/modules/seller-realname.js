require(['../common/common'],function(c){
    require(['jquery','template','md5','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		$.get('include/realnamecon.html', function(realdata) {
			/*optional stuff to do after success */
			var render = template.compile(realdata);
			//查看企业认证信息
			$.ajax({
				type: 'get',
				url: api + "/api/Cert_Ent?access_token="+access_token+"&user_id="+user_id,
				dataType: "json"
			}).then(function(realData){
				//console.log(realData)
				if (realData.err_code == 0) {
					if (realData.data == null) {
						$(".buyer-right-bottom").css({"display": "none"});
						$(".buyer-data-null").css({"display": "block"});
					}else{
						var html = render(realData);
						$("#realnamecon").html(html);

						$(".buyer-right-bottom div").eq(11).find("span").eq(1).on("click", function(){
							window.open(realData.data.cert_img);
						});
					}
				}else{
					$(".buyer-right-bottom").css({"display": "none"});
					$(".buyer-data-null").html(realData.msg).css({"display": "block"});
				}
			});
		});

		$.get("include/realnameper.html", function(realperdata){
			var render = template.compile(realperdata);
			//查看个人认证信息
			$.ajax({
				type: "get",
				url: api + "/api/Cert_User?access_token="+access_token+"&user_id="+user_id,
				dataType: "json"
			}).then(function(personData){
				if (personData.err_code == 0) {
					if (personData.data == null) {
						$(".buyer-right-bottom-p").css({"display": "none"});
						$(".buyer-data-null-person").css({"display": "block"});
					}else{

						var html = render(personData);
						$("#realnameper").html(html);

						$(".buyer-right-bottom-p div").eq(2).find("span").eq(1).on("click", function(){
							window.open(personData.data.id_card_img);
						});
					}
				}else{
					$(".buyer-right-bottom-p").css({"display": "none"});
					$(".buyer-data-null-person").html(personData.msg).css({"display": "block"});
				}
			});
		});
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(6)").find("a").css({"color": "#ff3c00"});
		//未认证跳转
		$('.buyer-data-null button,.buyer-data-null-person button').on('click', function(){
			$.cookie('tz', '1', {path: '/', domain: 'bancai.com'});
			window.location.href = 'http://www.bancai.com/identification_one.html';
		});
		//审核失败的跳转
		$('#realnamecon').on('click', '.rz-gai', function(){
			$.cookie('tz', '1', {path: '/', domain: 'bancai.com'});
			window.location.href = 'http://www.bancai.com/identification_one.html';
		});
		$('#realnameper').on('click', '.rz-gai', function(){
			$.cookie('tz', '1', {path: '/', domain: 'bancai.com'});
			window.location.href = 'http://www.bancai.com/identification_one.html';
		});
    });
});