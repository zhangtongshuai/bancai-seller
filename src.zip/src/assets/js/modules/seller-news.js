require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','pager','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		var shop_id = $.cookie('shop_id');
		if (shop_id != 0) {
			//init
		    $(function () {
		        searchFilter(1)
		    });
		    
			function searchFilter(pageindex){
				var pageNo = getParameter('pageIndex');
	            if (!pageNo) {
	                pageNo = pageindex;
		        }
				$.ajax({
					url: api+"/api/shop_articals?access_token="+access_token+"&user_id="+user_id+'&shop_id='+shop_id+"&page_no="+pageNo,
					type: 'get',
					dataType: 'json',
					success:function(result){
						//console.log(result);
						if (result.err_code != 0) {
							layer.alert(result.msg, {'title': false,'closeBtn': 0});
							return false;
						}
						var count = parseInt(result.data.total_record);
	                    var totalPage = parseInt(result.data.total_page);
	                    if (count == 0) {
	                    	$('#no-data').show();
	                    }else{
		                    var html = template('newsList', result.data.list);
							$('#news').html(html);
							//生成分页
							kkpager.generPageHtml({
								pno: pageNo,
								//总页码
								total : totalPage,
								//总数据条数
								totalRecords : count,
								mode : 'click',
								click : function(n){
								    this.selectPage(pageNo);
				                    searchPage(n);
				                    return false;
								}
							},true);
	                    }
						
					},
					error: function () {
	                    layer.msg('网络请求失败，请刷新后重试！');
	                }	
				})
			}
			//ajax翻页
		    function searchPage(n) {
		        searchFilter(n);
		    }
			//分页数量
			function getParameter(name) { 
				var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
				var r = window.location.search.substr(1).match(reg); 
				if (r!=null) return unescape(r[2]); return null;
			}
			
		}else{
			layer.alert('您还未开通店铺', {'title': false,'closeBtn': 0});
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(6).find("dd:nth-of-type(6)").find("a").css({"color": "#ff3c00"});
		//点击编辑按钮
		$('#news').on('click', '.edit', function(){
			var news_id = $(this).parents('.news').data().newsid;
			$.cookie('news_id', news_id);
			localStorage.setItem('newqu', 1);
			window.location.href = 'seller-new.html';
		});
		//点击删除按钮
		$('#news').on('click', '.del', function(){
			var that = this;
			var news_id = $(this).parents('.news').data().newsid;
			layer.confirm('您确定要删除此资讯吗？', {'title': false,'closeBtn': 0}, function(i){
				$.ajax({
					type: "delete",
					url: api+'/api/shop_articals?access_token='+access_token+'&user_id='+user_id+'&shop_id='+shop_id+'&news_id='+news_id,
					async: true,
					dataType: 'json'
				}).then(function(result){
					//console.log(result);
					if(result.err_code == 0){
						$(that).parents('.news').remove();
						layer.alert('删除成功', {'title': false,'closeBtn': 0});
					}else{
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
					}
				});
				//关闭弹出框
				layer.close(i);
			});
		});
    });
});