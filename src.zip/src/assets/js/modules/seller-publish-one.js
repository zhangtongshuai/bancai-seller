require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','slider','base','spec'], function($,template,md5,layui,cookie) {

		/**
		 * 数据渲染
		 */

		/**
		 * 交互效果
		 */
		var shop_id = $.cookie('shop_id');
		if(shop_id == 0){
			layer.alert('您没有开通店铺', {'title': false,'closeBtn': 0}, function(){
				window.location.href = 'seller-shop.html';
			});
		}
		
		//下拉框
		var jsonobjct = eval(cateList);
		var json = jsonobjct.cate;
		// 一级    
		var option1 = '';
		$.each(json, function(index, indexItems) {
			option1 += "<option >" + indexItems.name + "</option>";
		});
		$("#catgory").append(option1);
		$("#catgory").on("change", function() {
			$('.buyer-pinlei select').css({'color': '#333'});
			selectpname(json);
			//selectpname1(json);
		});
		// 2-1 
		function selectpname(data) {
			var option2 = '';
			var selectedIndex = $("#catgory :selected").text();
			$("#pname").empty();
			$.each(data, function(index, indexItems) {
				if(indexItems.name != selectedIndex) {
					return;
				} else {
					$.each(indexItems.pname, function(index, Items) {
						option2 += "<option>" + Items + "</option>";
					});
				}
			});
			$("#pname").append(option2);
		};
		// 2-2
		function selectpname1(data) {
			var option3 = '';
			var selectedIndex = $("#name :selected").text();
			$("#spec").empty();
			$.each(data, function(index, indexItems) {
				if(indexItems.name != selectedIndex) {
					return;
				} else {
					$.each(indexItems.spec, function(index, Items) {
						option3 += "<option>" + Items + "</option>";
					});
				}

			});
			$("#spec").append(option3);
		};

		//获取并设置选中值
		$('#down-step').on("click", function() {
			var catagory = $('#catgory option:selected').text(),
				pname = $('#pname option:selected').text();
			
			$.cookie('catagory', catagory);
			$.cookie('pname', pname);
			$.removeCookie('sku_id');
			$.removeCookie('different');
			
			switch(catagory){
				case '胶合板':
					window.location.href = 'seller-publish-jhb.html';
					break;
				
				case '密度板':
					window.location.href = 'seller-publish-mdb.html';
					break;
					
				case '刨花板':
					window.location.href = 'seller-publish-bhb.html';
					break;
					
				case '单板':
					window.location.href = 'seller-publish-db.html';
					break;
					
				case '面底板':
					window.location.href = 'seller-publish-mdib.html';
					break;
					
				case '实木板':
					window.location.href = 'seller-publish-smb.html';
					break;
			}
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
	});
});