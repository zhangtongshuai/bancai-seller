require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
//		var user_id = 1000000006,
//			access_token = "99de94e9-8ce1-4d72-a01e-8859abe3e1e6";
		
		//获取shopid
		$.ajax({
			type: 'get',
			url: api + '/api/shopid?access_token='+access_token+'&user_id='+user_id,
			dataType: 'json'
		}).then(function(certData){
			//console.log(certData)
			if (certData.err_code == 0) {
				if (certData.data == 0) {
					$.cookie('shop_id', 0);
					layer.alert('您还未开通店铺', {'title': false,'closeBtn': 0});
				}else{					
					$.cookie('shop_id', certData.data);
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		//获取卖家的各种信息
		$.ajax({
			type: "get",
			url: api+'/api/index_seller?access_token='+access_token+'&user_id='+user_id,
			async: true,
			dataType: 'json'
		}).then(function(sellerMsg){
			//console.log(sellerMsg);
			if(sellerMsg.err_code == 0){
				$('.index-one .permsg strong').html(sellerMsg.data.user_info.user_name);
				$('.index-one .permsg em:eq(0) b').html(sellerMsg.data.user_info.phone_no);
				$('.index-one .permsg em:eq(1) b').html(sellerMsg.data.user_info.email);
				
				if(sellerMsg.data.shop_info != null || sellerMsg.data.shop_info != ''){
					$('.index-one li:eq(2) div:eq(1) span:eq(0) b').html(sellerMsg.data.shop_info.shop_name);
					if(sellerMsg.data.shop_info.is_vip == 1){
						$('.index-one li:eq(2) div:eq(1) span:eq(0) img').attr({'src': 'assets/images/vip.png'});
					}else{
						$('.index-one li:eq(2) div:eq(1) span:eq(0) img').attr({'src': 'assets/images/vip-gray.png'});
					}
					$('.index-one li:eq(2) div:eq(1) span:eq(1) em').addClass('jb'+(parseInt(sellerMsg.data.shop_info.level)+1));
					$('.index-one li:eq(2) div:eq(1) span:eq(2) em').html(sellerMsg.data.shop_info.register_time);
					$('.index-one li:eq(2) div:eq(1) span:eq(3) em').html(sellerMsg.data.shop_info.jf);
				}else{
					layer.alert('您还未开通店铺', {'title': false,'closeBtn': 0})
				}
				
				//店铺vip
				localStorage.setItem('shop_vip', sellerMsg.data.shop_info.is_vip);
				
				//消息数量
				localStorage.setItem('unread_msg', sellerMsg.data.counts.unread_msg);
				localStorage.setItem('order_wfk', sellerMsg.data.counts.order_wfk);
				localStorage.setItem('order_process', sellerMsg.data.counts.order_process);
				
				if(sellerMsg.data.messages != null && sellerMsg.data.messages.length != 0){
					$('#no-data').hide();
					var msghtml = template('msglist', sellerMsg.data.messages);
					$('.index-two .msglist').html(msghtml);
				}else{
					$('#no-data').show();
				}
				
				if(sellerMsg.data.purchase != null && sellerMsg.data.purchase.length != 0){
					$('#no-data-order').hide();
					var orderhtml = template('orderlist', sellerMsg.data.purchase);
					$('.index-three .orderlist ul').html(orderhtml);
				}else{
					$('#no-data-order').show();
				}
				
				if(sellerMsg.data.products != null && sellerMsg.data.products.length != 0){
					$('#no-data-dai').hide();
					var dfhtml = template('dfblist', sellerMsg.data.products);
					$('.index-four .dfblist').html(dfhtml);
				}else{
					$('#no-data-dai').show();
				}
				
				//消息数量
		        var hSpan = localStorage.getItem('unread_msg');
				
		        //消息右上角的数量显示隐藏
				if(parseInt(hSpan) > 0) {
					$(".header-top-box h2").eq(1).find("span").css({'display': 'inline-block'}).html(hSpan);
					if (parseInt(hSpan) >= 100) {
						$(".header-top-box h2").eq(1).find("span").text('99');
					}
				}else{
					$(".header-top-box h2").eq(1).find("span").hide();
				}
				
				//订单显示
				var order_wfk = localStorage.getItem('order_wfk'),
					order_process = localStorage.getItem('order_process');
				
				if(order_wfk > 100){
					order_wfk = 99;
				}
				if(order_process > 100){
					order_process = 99;
				}
				
				if(order_wfk > 0){
					$('.seller-size .order-xian-shi span.order-wfk').html(order_wfk).show();
				}else{
					$('.seller-size .order-xian-shi span.order-wfk').hide();
				}
				
				if(order_process > 0){
					$('.seller-size .order-xian-shi span.order-doing').html(order_process).show();
				}else{
					$('.seller-size .order-xian-shi span.order-doing').hide();
				}
			}else{
				layer.alert(sellerMsg.msg, {'title': false,'closeBtn': 0});
			}
		});
    	/**
    	 * 交互效果
    	 */
    	//点击消息
		$('.msglist').on('click', '.chuanmsgid', function(){
			var unread_msg = localStorage.getItem('unread_msg');
			--unread_msg;
			if(unread_msg < 0){
				unread_msg = 0;
			}
			localStorage.setItem('unread_msg', unread_msg);
			if(unread_msg > 99){
				unread_msg  = 99;
			}
			$(".header-top-box h2").eq(1).find("span").html(unread_msg);
			
			var msgidget = $(this).parents('ul').data().msgid;
			window.location.href = 'http://seller.bancai.com/seller-msg-details.html?msg_id='+msgidget;
		});
		//消息列表移入移除
//		$('.msglist').on('mouseenter', 'li.msg-content-index', function(){
//			$(this).children('div').addClass('bgcolor');
//			$(this).children('span').addClass('bgcolor');
//		}).on('mouseleave', 'li.msg-content-index', function(){
//			$(this).children('div').removeClass('bgcolor');
//			$(this).children('span').removeClass('bgcolor');
//		});
    });
});