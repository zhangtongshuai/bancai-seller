require(['../common/common'],function(c){
    require(['jquery','template','md5','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
        /**
         * 交互效果
         */

            var user_id = $.cookie('user_id'),
                access_token = $.cookie('access_token');
            function GetQueryString(name)
            {
                var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
                var r = window.location.search.substr(1).match(reg);
                if(r!=null)return  unescape(r[2]); return null;
            }
            var msg_id = GetQueryString("msg_id");
            //获取收到的消息
            $.ajax({
                type: 'get',
                url: api + '/api/message_detail?access_token='+access_token+'&user_id='+user_id+'&msg_id='+msg_id,
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                success:function(r){
                    //console.log(r);
                    if(r.data != null){
                        $("#message_title").html(r.data.title);
                        $("#message_pub_time").html(r.data.pub_time);
                        $("#message_content").html(r.data.content);
                    }
                }
            });

    });
});