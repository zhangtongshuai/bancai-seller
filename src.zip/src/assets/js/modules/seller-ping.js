require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','pager','slider','base'], function($,template,md5,layui,cookie) {

		/**
		 * 数据渲染
		 */
		var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		//init
	    $(function () {
	        searchFilter(1)
	    });
	    
		function searchFilter(pageindex){
			var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
	        }
			$.ajax({
				url: api+"/api/er_pay_s?access_token="+access_token+"&user_id="+user_id+"&page_no="+pageNo,
				type: 'get',
				dataType: 'json',
				success:function(result){
					//console.log(result);
					if (result.err_code != 0) {
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
						return false;
					}
					var count = parseInt(result.data.record_count);
                    var totalPage = parseInt(result.data.page_total);
                    if (count == 0) {
                    	$('#no-data').show();
                    }else{
	                    var html = template('order', noData.data.list);
						$('#order-zhan').html(html);
						//生成分页
						kkpager.generPageHtml({
							pno: pageNo,
							//总页码
							total : totalPage,
							//总数据条数
							totalRecords : count,
							mode : 'click',
							click : function(n){
							    this.selectPage(pageNo);
			                    searchPage(n);
			                    return false;
							}
						},true);
                    }
					
				},
				error: function () {
                    layer.msg('网络请求失败，请刷新后重试！');
                }	
			})
		}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
		/**
		 * 交互效果
		 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
	});
});