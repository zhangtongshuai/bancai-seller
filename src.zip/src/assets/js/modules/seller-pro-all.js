require(['../common/common'], function(c) {
	require(['jquery','template','layui','cookie','base','pager'], function($,template) {

		/**
		 * 数据渲染
		 */
		var cookieMsg = $.cookie(),
			access_token = cookieMsg.access_token,
			user_id = cookieMsg.user_id;
		
		//进入页面时获得的数据
		//init
	    $(function () {
	        searchFilter(1)
	    });
	    
		function searchFilter(pageindex){
			var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
	        }
            
			$.ajax({
				url: api+"/api/product?access_token="+access_token+"&user_id="+user_id+"&page_no="+pageNo,
				type: 'get',
				dataType: 'json',
				success:function(result){
					//console.log(result);
					if (result.err_code != 0) {
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
						return false;
					}
					var count = parseInt(result.data.record_count);
                    var totalPage = parseInt(result.data.page_total);
                    if (count == 0) {
                    	$('table').after('<p>没有数据</p>');
                    }else{
	                    var data = result.data.list;
	                    var html = template('protemplate', data);
						$('table tbody').html(html);
						//生成分页
						kkpager.generPageHtml({
							pno: pageNo,
							//总页码
							total : totalPage,
							//总数据条数
							totalRecords : count,
							mode : 'click',
							click : function(n){
							    this.selectPage(pageNo);
			                    searchPage(n);
			                    return false;
							}
						},true);
                    }
					$('.buyer-right-bottom table td').on('click', 'a:eq(0)', function(){
						if ($(this).hasClass('layui-btn-disabled')) {
							return;
						}
						var prosku = $(this).parents('tr').data();
						$.cookie('catagory', prosku.catagory);
						$.cookie('pname', prosku.pname);
						$.cookie('sku_id', prosku.skuid);
						$.cookie('different', 1);
						switch(prosku.catagory){
							case '胶合板':
								window.location.href = 'seller-publish-jhb.html';
								break;
							case '面底板':
								window.location.href = 'seller-publish-mdib.html';
								break;
							case '刨花板':
								window.location.href = 'seller-publish-bhb.html';
								break;
							case '单板':
								window.location.href = 'seller-publish-db.html';
								break;
							case '密度板':
								window.location.href = 'seller-publish-mdb.html';
								break;
							case '实木板':
								window.location.href = 'seller-publish-smb.html';
								break;
						}
					});
					$('.buyer-right-bottom table td').on('click', 'a:eq(1)', function(){
						if ($(this).hasClass('layui-btn-disabled')) {
							return false;
						}
						var that = this;
						var prosku = $(this).parents('tr').data();
						//console.log(prosku);
						if (prosku.status == '4') {
							var content = {
								"sku_id": prosku.skuid,
								"status": "2"
							};
							$.ajax({
								type: "post",
								url: api+"/api/product?access_token="+access_token+"&user_id="+user_id,
								async: true,
								data: JSON.stringify(content),
								dataType: 'json'
							}).then(function(upData){
								//console.log(upData);
								if (upData.err_code != 0) {
									layer.alert(upData.msg, {'title': false,'closeBtn': 0});
									return false;
								}
								layer.alert('上架成功', {'title': false,'closeBtn': 0}, function(i){
									//window.location.reload();
									$(that).addClass('layui-btn-disabled').next().removeClass('layui-btn-disabled').addClass('layui-btn-danger');
									$(that).parents('tr').attr('data-status', '2');
									$(that).parent('td').prev().html('正常');
									
									layer.close(i);
								});
							});
						}else if (prosku.status == '5') {
							layer.alert('此商品不能上架', {'title': false,'closeBtn': 0});
						}
						
					});
					$('.buyer-right-bottom table td').on('click', 'a:eq(2)', function(){
						if ($(this).hasClass('layui-btn-disabled')) {
							return false;
						}
						var that = this;
						var prosku = $(this).parents('tr').data();
						var content = {
							"sku_id": prosku.skuid,
							"status": "4"
						};
						$.ajax({
							type: "post",
							url: api+"/api/product?access_token="+access_token+"&user_id="+user_id,
							async: true,
							data: JSON.stringify(content),
							dataType: 'json'
						}).then(function(downData){
							//console.log(downData);
							if (downData.err_code != 0) {
								layer.alert(downData.msg, {'title': false,'closeBtn': 0});
								return false;
							}
							layer.alert('下架成功', {'title': false,'closeBtn': 0}, function(i){
								//window.location.reload();
								$(that).addClass('layui-btn-disabled').prev().removeClass('layui-btn-disabled');
								$(that).parents('tr').attr('data-status', '4');
								$(that).parent('td').prev().html('下架');
								
								layer.close(i);
							});
						});
					});
				},
				error: function () {
                    layer.msg('网络请求失败，请刷新后重试！');
                }	
			})
		}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
		/**
		 * 交互效果
		 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
	});
});