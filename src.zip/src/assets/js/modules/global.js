define(function(){
	return "http://192.168.100.90/api";
});