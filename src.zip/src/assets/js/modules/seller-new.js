require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		var oldData;//表示原来的数据
		
		//上传编辑器实例化
		var ue = UE.getEditor('editor',{maximumWords: 5000});
		
		var shop_id = $.cookie('shop_id'),
			news_id = $.cookie('news_id');
			
		var newqu = localStorage.getItem('newqu');
		if(shop_id != 0){
			if(newqu == 1){
				if(typeof news_id != 'undefined'){
					$.ajax({
						type: 'get',
						url: api+'/api/shop_articals?access_token='+access_token+'&user_id='+user_id+'&news_id='+news_id+'&from=bg',
						dataType: 'json'
					}).then(function(certData){
						//console.log(certData);
						if (certData.err_code == 0) {
							if (certData.data != null) {
								oldData = certData;
								$('#zxtitle').val(certData.data.title);
								$('#zxkeyword').val(certData.data.keywords);
								ue.ready(function(){
								    ue.setContent(certData.data.content);
								});
							}
						}else{
							layer.alert(certData.msg, {'title': false,'closeBtn': 0});
						}
					});
				}
			}
		}else{
			layer.alert('您还未开通店铺', {'title': false,'closeBtn': 0}, function(){
				window.location.href = 'seller-shop.html';
			});
		}
		
		localStorage.removeItem('newqu');
		
		/*点击发布按钮*/
		$('.buyer-right-bottom div.layui-btn').on('click', function(){
			//内容
			var arrEditor = [],
				content;//内容详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        content = arrEditor.join("\n");
			
			var newsObj = {
				'news_id': 0,
				'shop_id': shop_id,
				'title': $('#zxtitle').val(),
				'keywords': $('#zxkeyword').val(),
				'content': content
			};
			if(typeof news_id != 'undefined'){
				newsObj.news_id = news_id;
			}
			fb(newsObj);
		});
		
		function fb(newsObj){
			if('' == newsObj.title){
				layer.alert('标题没有填写', {'title': false,'closeBtn': 0});
			}else if(newsObj.title.indexOf(' ') >= 0){
				layer.alert('标题中不能有空格', {'title': false,'closeBtn': 0});
			}else if('' == newsObj.content.trim()){
				layer.alert('内容没有填写', {'title': false,'closeBtn': 0});
			}else{
				if(newsObj.keywords.trim() != ''){
					newsObj.keywords = changeDouHao(newsObj.keywords);
				}
				$.ajax({
					type: 'post',
					url: api+'/api/shop_articals?access_token='+access_token+'&user_id='+user_id,
					data: JSON.stringify(newsObj),
					dataType: 'json'
				}).then(function(result){
					if(result.err_code == 0){
						layer.alert('发布成功', {'title': false,'closeBtn': 0}, function(){
							window.location.href = 'seller-news.html';
						});
					}else{
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
					}
				});
			}
		}
		//将中文逗号转换成英文逗号
		function changeDouHao(str){
			str=str.replace(/，/ig,',');
			return str;
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(6).find("dd:nth-of-type(5)").find("a").css({"color": "#ff3c00"});
    });
});