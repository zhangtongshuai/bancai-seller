require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
			
		//默认是灰色的按钮并且没有点击事件
		$(".buyer-right-bottom button").css({'background-color': '#999'});
		//获取联系人信息
		$.ajax({
			type: 'get',
			url: api + '/api/Contacts',
			data: {
				"user_id": user_id,
				"access_token": access_token
			},
			dataType: 'json'
		}).then(function(certData){
			if (certData.err_code == 0) {
				if (certData.data != null) {
					$("#contains-btn").val(certData.data.contacts);
					$("#phone-btn").val(certData.data.phone_no);
					$("#email-btn").val(certData.data.email);
				}else{
					$("#contains-btn").focus();
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		$("#contains-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#phone-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#email-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#contains-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#phone-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#email-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		
		var regPhone = /^1(3|4|5|7|8)\d{9}$/;
		var regEmail = /[_a-z\d\-\./]+@[_a-z\d\-]+(\.[_a-z\d\-]+)*(\.(info|biz|com|edu|gov|net|am|bz|cn|cx|hk|jp|tw|vc|vn))$/;
		
		function changeContains(){
			var containsObj = {
				user_id: user_id,
				access_token: access_token,
				contacts: $("#contains-btn").val(),
				phone_no: $("#phone-btn").val(),
				email: $("#email-btn").val()
			};
			//console.log(containsObj);
			if (containsObj.contacts.trim() == "") {
				$(".buyer-right-bottom > span").html("联系人信息不能为空或有空格");
				$("#contains-btn").focus();
				return false;
			}else if (containsObj.phone_no == "" || !regPhone.test(containsObj.phone_no)) {
				$(".buyer-right-bottom > span").html("电话格式不正确");
				$("#phone-btn").focus();
				return false;
			}else if (containsObj.email == "" || !regEmail.test(containsObj.email)) {
				$(".buyer-right-bottom > span").html("邮箱格式不正确");
				$("#email-btn").focus();
				return false;
			}else{
				$.ajax({
					type: "post",
					url: api + "/api/Contacts",
					async:true,
					data: JSON.stringify(containsObj),
					dataType: "json"
				}).then(function(changmsg){
					if(changmsg.err_code == 0){
						window.location.reload();
					}else{
						layer.alert(changmsg.msg, {'title': false,'closeBtn': 0});
					}
				});
			}
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(3)").find("a").css({"color": "#ff3c00"});
    });
});