require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','area','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		var oldData;//表示原来的数据
		
		//获取联系人信息
		$.ajax({
			type: 'get',
			url: api + '/api/shr?access_token='+access_token+'&user_id='+user_id,
			data: {
				"user_id": user_id,
				"access_token": access_token
			},
			dataType: 'json'
		}).then(function(certData){
			if (certData.err_code == 0) {
				if (certData.data != null) {
					oldData = certData.data;
					$('.shr-xiu-gai').show();
					$('.shr-bao-cun').hide();
					$(".shr-xiu-gai div:eq(0) em").html(certData.data.shr);
					$(".shr-xiu-gai div:eq(1) em").html(certData.data.province + certData.data.city + certData.data.district);
					$(".shr-xiu-gai div:eq(2) em").html(certData.data.shr_address);
					$(".shr-xiu-gai div:eq(3) em").html(certData.data.shr_phone);
					
					$(".shr-xiu-gai div:eq(0) input").val(certData.data.shr);
					$('.shr-xiu-gai .province option:selected').text(certData.data.province);
					$('.shr-xiu-gai .city option:selected').text(certData.data.city);
					$('.shr-xiu-gai .district option:selected').text(certData.data.district);
				
					$(".shr-xiu-gai div:eq(2) input").val(certData.data.shr_address);
					$(".shr-xiu-gai div:eq(3) input").val(certData.data.shr_phone);
				}else{
					$('.shr-bao-cun').show();
					$('.shr-xiu-gai').hide();
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		
		/*手机号的正则*/
		var regPhone = /(^((0\d{3}|(400|800))-)?\d{7,8}$)|(^1[3-9][0-9]{9}$)/;
		
		
		/*点击保存按钮*/
		$('.shr-bao-cun div').eq(4).find('span:eq(0)').on('click', function(){
			var containsObj = {
				'shr': $("#shr").val(),
				'province': $(".shr-bao-cun .province option:selected").text(),
				'city': $(".shr-bao-cun .city option:selected").text(),
				'district': $(".shr-bao-cun .district option:selected").text(),
				'shr_address': $('#shr-xx-address').val(),
				'shr_phone': $('#shr-phone').val()
			};
			changeContains(containsObj);
		});
		/*点击取消按钮*/
		$('.cert-bao-cun div').eq(3).find('span:eq(1)').on('click', function(){
			$("#shr").val('');
			$(".shr-bao-cun .province option:selected").text('请选择');
			$(".shr-bao-cun .city option:selected").text('请选择');
			$(".shr-bao-cun .district option:selected").text('请选择');
			$("#shr-xx-address").val('');
			$("shr-phone").val('');
		});
		/*点击修改按钮*/
		var gai = 0;//0表示第一次点击修改，1表示进行数据提交
		$('.shr-xiu-gai div').eq(4).find('span').on('click', function(){
			var containsObj = {
				'shr': $("#gai-shr").val(),
				'province': $(".shr-xiu-gai .province option:selected").text(),
				'city': $(".shr-xiu-gai .city option:selected").text(),
				'district': $(".shr-xiu-gai .district option:selected").text(),
				'shr_address': $('#gai-shr-xx-address').val(),
				'shr_phone': $('#gai-shr-phone').val()
			};
			if(gai == 0){
				$('.shr-xiu-gai em').hide();
				$('.shr-xiu-gai .area').show();
				$('.shr-xiu-gai .area').css({'display': 'inline-block'});
				$('#gai-shr').show();
				$('#gai-shr-xx-address').show();
				$('#gai-shr-phone').show();
				gai = 1;
			}else{
				changeContains(containsObj);
			}
		});
		
		
		function changeContains(containsObj){
			//console.log(JSON.stringify(containsObj));
			if(containsObj.shr == ""){
				layer.alert('收货人信息不能为空', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.shr.indexOf(' ') >= 0){
				layer.alert('收货人信息不能有空格', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.province == "省份") {
				layer.alert('省份未选择', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.city == "请选择") {
				layer.alert('城市未选择', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.district == "请选择") {
				layer.alert('区/县未选择', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.shr_phone == "" || !regPhone.test(containsObj.shr_phone)) {
				layer.alert('电话格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}
			
			$.ajax({
				type: "post",
				url: api + '/api/shr?access_token='+access_token+'&user_id='+user_id,
				async:true,
				data: JSON.stringify(containsObj),
				dataType: "json"
			}).then(function(changmsg){
				if(changmsg.err_code == 0){
					window.location.reload();
				}else{
					layer.alert(changmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		}
		
		
		var baoObj = {
			province: $("#province-bao"),
			city: $("#city-bao"),
			town: $("#district-bao")
		};
		var gaiObj = {
			province: $("#province-gai"),
			city: $("#city-gai"),
			town: $("#district-gai")
		};
		address(baoObj);
		address(gaiObj);
		
		function address(obj){
			//地区
			var province = obj.province,
				city = obj.city,
				town = obj.town;
			for(var i = 0; i < provinceList.length; i++){
				addEle(province, provinceList[i].name);
			}
	
			function addEle(ele, value){
				var optionStr = "";
				optionStr = "<option value=" + value + ">" + value + "</option>";
				ele.append(optionStr);
			}
	
			function removeEle(ele){
				ele.find("option").remove();
				var optionStar = "<option value=" + "请选择" + ">" + "请选择" + "</option>";
				ele.append(optionStar);
			}
			var provinceText, cityText, cityItem;
			province.on("change", function() {
				provinceText = $(this).val();
				$("#province-bao").attr("val", provinceText);
				$.each(provinceList, function(i, item) {
					if(provinceText == item.name){
						cityItem = i;
						return cityItem
					}
				});
				removeEle(city);
				removeEle(town);
				$.each(provinceList[cityItem].cityList, function(i, item){
					addEle(city, item.name);
				});
			});
			city.on("change", function(){
				cityText = $(this).val();
				$("#city-bao").attr("val", cityText);
				removeEle(town);
				$.each(provinceList, function(i, item){
					if(provinceText == item.name){
						cityItem = i;
						return cityItem
					}
				});
				$.each(provinceList[cityItem].cityList, function(i, item){
					if(cityText == item.name){
						for(var n = 0; n < item.areaList.length; n++){
							addEle(town, item.areaList[n])
						}
					}
				});
			});
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
    });
});