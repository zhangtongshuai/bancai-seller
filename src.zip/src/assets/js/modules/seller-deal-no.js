require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','slider','base'], function($,template,md5,layui,cookie) {

		/**
		 * 数据渲染
		 */
		template.defaults.imports.phoneStar = function(obj){
			var arr = obj.split('');
			for (let i=0; i<arr.length; i++) {
				if (i<7 && i>2) {
					arr[i] = '*';
				}
			}
			return arr.join('');
		}
		
		var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		$.ajax({
			type: "get",
			url: api+"/api/order_unpay_s?access_token="+access_token+"&user_id="+user_id,
			async:true,
			dataType: 'json'
		}).then(function(noData){
			//console.log(noData);
			if (noData.err_code == 0) {
				if (noData.data != '') {
					var shop_vip = localStorage.getItem('shop_vip');
					if(shop_vip == 1){
						var html = template('order-vip', noData.data);
						$('#order-zhan').html(html);
					}else{
						var html = template('order', noData.data);
						$('#order-zhan').html(html);
					}
					localStorage.setItem('order_wfk', noData.data.length);
				}else{
					$('#no-data').show();
				}
			}else{
				layer.alert(noData.msg, {'title': false,'closeBtn': 0});
			}
		});
		
		/**
		 * 交互效果
		 */
		/*点击改价按钮*/
		$('#order-zhan').on('click', '.left5', function(){
			$(this).parents('.seller-bottom').children('.gai-price').css({'display': 'block'});
		});
		/*点击开票信息按钮*/
		$('#order-zhan').on('click', '.fpzi', function(){
			$(this).parents('.seller-bottom').children('.fpmsg').css({'display': 'block'});
		});
		/*点击发票信息的叉号*/
		$('#order-zhan').on('click', 'i.fpcha', function(){
			$(this).parents('.fpmsg').hide();
		});
		
		/*点击改价弹出框的按钮*/
		/*确认按钮*/
		$('#order-zhan').on('click', '.que1', function(){
			var danhao = $(this).parents('.seller-bottom').find('.seller-bottom-top span:eq(1) em').html();
			var newPrice = $(this).parents('.seller-bottom').find('.gaihou').val();
			if ('' == newPrice) {
				layer.alert('修改后价格没有填写', {'title': false,'closeBtn': 0});
				return false;
			}else if (!/^((0|([1-9]\d*))(\.\d{1,2})?)?$/.test(newPrice)) {
				layer.alert('修改后价格格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}
			var that = this;
			var content = {
				"order_id": danhao,
				"price": newPrice
			};
			$.ajax({
				type: "post",
				url: api+"/api/order_chg_price?access_token="+access_token+"&user_id="+user_id,
				async:true,
				data: JSON.stringify(content),
				dataType: 'json'
			}).then(function(result){
				if (result.err_code == 0) {
					layer.alert('修改成功', {'title': false,'closeBtn': 0});
					$(that).parents('.gai-price').hide();
					$(that).parents('.gai-price').siblings('.seller-bottom-bottom').find('.bottom-right span:eq(1) strong em').html(Number(newPrice));
				}else{
					layer.alert(result.msg, {'title': false,'closeBtn': 0});
				}
			});
		});
		/*取消按钮*/
		$('#order-zhan').on('click', '.quxiao1', function(){
			$(this).parents('.gai-price').hide();
		});
		$('#order-zhan').on('click', 'i.gaicha', function(){
			$(this).parents('.gai-price').hide();
		});
		
		/*点击取消订单按钮*/
		$('#order-zhan').on('click', '.quxiaodingdan', function(){
			var that = this;
			var quxiao_order = $(this).parents('.seller-bottom').find('.seller-bottom-top span:eq(1) em').html();
			var orderObj = {
				"order_id": quxiao_order,
				"user_type": '1'
			};
			layer.confirm('您是否确认要取消订单？', {'title': false,'closeBtn': 0}, function(i){
				$.ajax({
					type: "post",
					url: api+"/api/order_cancel?access_token="+access_token+"&user_id="+user_id,
					async:true,
					data: JSON.stringify(orderObj),
					dataType: 'json'
				}).then(function(orderData){
					//console.log(orderData);
					if (orderData.err_code == 0) {
						$(that).parents('.seller-bottom').remove();
						var order_wfk = localStorage.getItem('order_wfk');
						--order_wfk;
						localStorage.setItem('order_wfk', order_wfk);
						if(order_wfk > 0){
							$('.seller-size .order-xian-shi span.order-wfk').html(order_wfk).show();
						}else{
							$('.seller-size .order-xian-shi span.order-wfk').hide();
						}
						layer.alert('取消成功', {'title': false,'closeBtn': 0});
					}else{
						layer.alert(orderData.msg, {'title': false,'closeBtn': 0});
					}
				});
				//关闭弹出框
				layer.close(i);
			});
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
	});
});