require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
	 	user_id = 1000000006;
		access_token = 'f0b85bcf-b30d-4e81-972f-9af08bd6404e'
		var oldData;//原始数据
		//获取联系人信息
		$.ajax({
			type: 'get',
			url: api + "/api/invoice?access_token="+access_token+"&user_id="+user_id,
			dataType: 'json'
		}).then(function(certData){
			//console.log(certData);
			if (certData.err_code == 0) {
				if(certData.data.title != null){
					oldData = certData.data;
					$('.fp-bao-cun').hide();
					$('.fp-xiu-gai').show();
					$("#gai-dan").val(certData.data.title);
					$("#gai-code").val(certData.data.credit_code);
					$("#gai-address").val(certData.data.register_address);
					$("#gai-phone").val(certData.data.register_phone);
					$("#gai-bank").val(certData.data.bank);
					$("#gai-bank-ammount").val(certData.data.bank_account);
				}else{
					$('.fp-bao-cun').show();
					$('.fp-xiu-gai').hide();
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		
		
		var regPhone = /(^((0\d{3}|(400|800))-)?\d{7,8}$)|(^1[3-9][0-9]{9}$)/;
		var regNa = /^[A-Za-z0-9]+$/;
		
		/*点击保存按钮*/
		$('.fp-bao-cun div').eq(6).find('span:eq(0)').on('click', function(){
			var containsObj = {
				title: $("#cun-dan").val(),
				credit_code: $("#cun-code").val(),
				register_address: $("#cun-address").val(),
				register_phone: $("#cun-phone").val(),
				bank: $("#cun-bank").val(),
				bank_account: $("#cun-bank-ammount").val()
			};
			changeContains(containsObj);
		});
		/*点击取消按钮*/
		$('.fp-bao-cun div').eq(6).find('span:eq(1)').on('click', function(){
			$("#cun-dan").val('');
			$("#cun-code").val('');
			$("#cun-address").val('');
			$("#cun-phone").val('');
			$("#cun-bank").val('');
			$("#cun-bank-ammount").val('');
		});
		/*点击修改按钮*/
		$('.fp-xiu-gai div').eq(6).find('span:eq(0)').on('click', function(){
			$(this).hide().siblings().show();
			$('.fp-xiu-gai input').removeAttr('disabled').css({'border-color': '#ddd'});
		});
		//点击保存
		$('.cert-xiu-gai div').eq(6).find('span:eq(1)').on('click', function(){
			var containsObj = {
				title: $("#gai-dan").val(),
				credit_code: $("#gai-code").val(),
				register_address: $("#gai-address").val(),
				register_phone: $("#gai-phone").val(),
				bank: $("#gai-bank").val(),
				bank_account: $("#gai-bank-ammount").val()
			};
			changeContains(containsObj);
		});
		//点击取消
		$('.fp-xiu-gai div').eq(6).find('span:eq(2)').on('click', function(){
			$('.fp-xiu-gai div').eq(6).find('span').hide();
			$('.fp-xiu-gai div').eq(6).find('span:eq(0)').show();
			$('.fp-xiu-gai input').attr('disabled', true).css({'border-color': 'transparent'});
		});
		
		
		function changeContains(containsObj){
			//console.log(containsObj);
			if(containsObj.title == ""){
				layer.alert('单位名称不能为空', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.title.indexOf(' ') >= 0){
				layer.alert('单位名称不能有空格', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.credit_code.trim() == ""){
				layer.alert('纳税人识别码不能为空', {'title': false,'closeBtn': 0});
				return false;
			}else if(!regNa.test(containsObj.credit_code)){
				layer.alert('纳税人识别码格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.register_phone.trim() != '' && !regPhone.test(containsObj.register_phone)){
				layer.alert('注册电话格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.bank_account.trim() != '' && !/^[\da-zA-Z]+$/.test(containsObj.bank_account)){
				layer.alert('银行账户格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}
			
			$.ajax({
				type: "post",
				url: api + "/api/invoice?access_token="+access_token+"&user_id="+user_id,
				async:true,
				data: JSON.stringify(containsObj),
				dataType: "json"
			}).then(function(changmsg){
				//console.log(changmsg);
				if(changmsg.err_code == 0){
					window.location.reload();
				}else{
					layer.alert(changmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(9).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});