require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','area','fb','slider','base','spec'], function($,template,md5,layui,cookie,area) {

		/**
		 * 数据渲染
		 */
		//获取用户信息
		var cookieMsg = $.cookie(),
			access_token = cookieMsg.access_token,
			user_id = cookieMsg.user_id;
		
		//规格的产生
		$.each(cateList.cate[4].spec, function(i, v) {
			var options = '<option value="'+i+'">'+v+'</option>'
			$('#spec').append(options);
		});
		
		$.each(cateList.cate[4].spec, function(i, v) {
			var dds = '<dd lay-value="'+i+'">'+v+'</dd>'
			$('#spec').next().find('.layui-anim.layui-anim-upbit').append(dds);
		});
		
		$('#spec').next().find('.layui-anim.layui-anim-upbit dd').on('click', function(){
			$('#spec').next().find('input').val('');
			$('#spec').next().find('input').val($(this).html());
		});
		
		/**
		 * 交互效果
		 */
		//所有的全局变量
		var lockKey = 0, //0表示没有自定义的参数，1表示有自定义的参数
			clickNum = 0; //表示自定义参数的数量
		var arr = [], //自定义参数数组
			pro_id = 0,//传过来的产品id
			brr = []; //删除undefined后的数组
		var oldData; //点击编辑后原来的数据
		
		//基本信息
		$('.buyer-right-bottom.basemsg div.one').eq(0).find('span:nth-of-type(2)').html(cookieMsg.catagory);
		$('.buyer-right-bottom.basemsg div.one').eq(1).find('span:nth-of-type(2)').html(cookieMsg.pname);
		//编辑
		if (cookieMsg.different == 1) {
			$.ajax({
				type: "get",
				url: api+"/api/product_detail?access_token="+access_token+"&user_id="+user_id+"&catagory="+cookieMsg.catagory+"&sku_id="+cookieMsg.sku_id,
				async:true,
				dataType: 'json'
			}).then(function(proMsg){
				//console.log(proMsg);
				if(proMsg.err_code != 0){
					layer.alert(proMsg.msg, {'title': false,'closeBtn': 0});
					return false;
				}
				oldData = proMsg.data;
				pro_id = proMsg.data.sku_id;
				if (oldData.parameters != []) {		
					lockKey = oldData.parameters.length;
				}
				$('#publish-title').val(proMsg.data.title);
				$('#publish-keyword').val(proMsg.data.keyword);
				$('#product-key').val(proMsg.data.sku_code);
				
				//规格
				$('#spec').next().find('input').val(proMsg.data.spec);
				$('#deng_ji').next().find('input').val(proMsg.data.deng_ji);
				$('#pin_ban').next().find('input').val(proMsg.data.pin_ban);
				$('#ganzao_way').next().find('input').val(proMsg.data.gan_zao);
				$('#yong_tu').next().find('input').val(proMsg.data.yong_tu);
				$('#han_shui_lv').next().find('input').val(proMsg.data.han_shui_lv);
				//自定义的参数
				$.each(proMsg.data.parameters, function(index, item){
					var userDefined = '<div class="user-defined-demo"><span>参数名：</span><input type="text" maxlength="10" id="argue-name-' + index + '" value="'+item.para_name+'" /><span>&nbsp;&nbsp;&nbsp;&nbsp;参数值：</span><input type="text" maxlength="20" id="argue-value-' + index + '" value="'+item.para_value+'" /><i class="iconfont icon-garbagecan"></i></div>'
					$('.layui-form .user-defined-box').append(userDefined);
				});
				
				//订货信息
				//是否库存管理判断
				if (proMsg.data.is_manage_kc == 1) {
					$('.buyer-right-bottom.order .layui-input-block').eq(0).find('div').removeClass('layui-form-radioed').end().find('div:eq(0)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(0).find('i:eq(0)').html('').end().find('i:eq(1)').html('');
					$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').removeAttr('disabled').val(proMsg.data.kc_ammount);
				}else{
					$('.buyer-right-bottom.order .layui-input-block').eq(0).find('div').removeClass('layui-form-radioed').end().find('div:eq(1)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(0).find('i:eq(1)').html('').end().find('i:eq(0)').html('');
					$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').attr('disabled', true).val('0');
				}
				//单位选择判断
				if (proMsg.data.unit == '张') {
					$('.buyer-right-bottom.order .layui-input-block').eq(1).find('div').removeClass('layui-form-radioed').end().find('div:eq(0)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(1).find('i:eq(0)').html('').end().find('i:eq(1)').html('');
				}else{
					$('.buyer-right-bottom.order .layui-input-block').eq(1).find('div').removeClass('layui-form-radioed').end().find('div:eq(1)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(1).find('i:eq(1)').html('').end().find('i:eq(0)').html('');
				}
				//是否有样品判断
				if (proMsg.data.is_yang_pin == 1) {
					$('.buyer-right-bottom.order .layui-input-block').eq(4).find('div').removeClass('layui-form-radioed').end().find('div:eq(0)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(4).find('i:eq(0)').html('').end().find('i:eq(1)').html('');
				}else{
					$('.buyer-right-bottom.order .layui-input-block').eq(4).find('div').removeClass('layui-form-radioed').end().find('div:eq(1)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(4).find('i:eq(1)').html('').end().find('i:eq(0)').html('');
				}
				//是否议价判断
				if (proMsg.data.is_yj == 1) {
					$('.buyer-right-bottom.order .layui-input-block').eq(6).find('div').removeClass('layui-form-radioed').end().find('div:eq(0)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(6).find('i:eq(0)').html('').end().find('i:eq(1)').html('');
				}else{
					$('.buyer-right-bottom.order .layui-input-block').eq(6).find('div').removeClass('layui-form-radioed').end().find('div:eq(1)').addClass('layui-form-radioed');
					$('.buyer-right-bottom.order .layui-input-block').eq(6).find('i:eq(1)').html('').end().find('i:eq(0)').html('');
				}
				
				$('.buyer-right-bottom.order .layui-input-block').eq(3).find('input').val(proMsg.data.min_qd);
				$('.buyer-right-bottom.order .layui-input-block').eq(5).find('input').val(proMsg.data.price);
				$('.buyer-right-bottom.order .layui-input-block').eq(7).find('input').val(proMsg.data.fee);
				$('#province option:selected').text(proMsg.data.province);
				$('#city option:selected').text(proMsg.data.city);
				$('#town option:selected').text(proMsg.data.district);
				
				if (proMsg.data.product_images.length == 5) {
					$('.updata-box').hide();
				}
				//产品展示
				$.each(proMsg.data.product_images, function(index, item){
					$('.buyer-right-bottom.product-zhan ul').prepend('<li class="picc"><img src="'+item.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div></li>');
				});
				
				//产品详情
				ue.ready(function(){
				    ue.setContent(proMsg.data.details);
				});
			});
		}
		
		//自定义参数
		$('.user-defined span').eq(1).on("click", function() {
			var userDefined = '<div class="user-defined-demo"><span>参数名：</span><input type="text" id="argue-name-' + lockKey + '" value="" /><span>&nbsp;&nbsp;&nbsp;&nbsp;参数值：</span><input type="text" id="argue-value-' + lockKey + '" value="" /><i class="iconfont icon-garbagecan"></i></div>'
			$('.layui-form .user-defined-box').append(userDefined);
			++lockKey;
			arr.push("", "");
		});
		$('.user-defined-box').on("click", 'i', function() {
			var index = parseInt($(this).prev().attr('id').split('-')[2]);
			$(this).parent().remove();
			arr.splice(2 * index, 2);
		});

		//上传编辑器实例化
		var ue = UE.getEditor('editor',{maximumWords: 5000});
		
		//获取并设置选中值
		$('#fabu').on("click", function() {
	        //基本信息的信息
	        var catagory = cookieMsg.catagory,
	        	pname = cookieMsg.pname,
	        	title = $('#publish-title').val(),
	        	keyword_old = $('#publish-keyword').val(),
	        	keyword = changeDouHao(keyword_old),
	        	sku_code = $('#product-key').val();
	        
	        //规格参数的信息
			var spec = $('#spec').next().find('input').val(),
				deng_ji = $('#deng_ji').next().find('input').val(),
				pin_ban = $('#pin_ban').next().find('input').val(),
				han_shui_lv = $('#han_shui_lv').next().find('input').val(),
				gan_zao = $('#ganzao_way').next().find('input').val(),
				yong_tu = $('#yong_tu').next().find('input').val();
			
			//订货的信息
			var is_manage_kc = $('.buyer-right-bottom.order .layui-input-block').eq(0).find('div.layui-form-radioed').prev().val(),
				unit = $('.buyer-right-bottom.order .layui-input-block').eq(1).find('div.layui-form-radioed').prev().val(),
				kc_ammount = $('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val(),
				min_qd = $('.buyer-right-bottom.order .layui-input-block').eq(3).find('input').val(),
				is_yang_pin = $('.buyer-right-bottom.order .layui-input-block').eq(4).find('div.layui-form-radioed').prev().val(),
				price = $('.buyer-right-bottom.order .layui-input-block').eq(5).find('input').val(),
				is_yj = $('.buyer-right-bottom.order .layui-input-block').eq(6).find('div.layui-form-radioed').prev().val(),
				fee = $('.buyer-right-bottom.order .layui-input-block').eq(7).find('input').val(),
				province = $('#province option:selected').text(),
				city = $('#city option:selected').text(),
				district = $('#town option:selected').text();
			
			//产品展示的信息
			var piccLen = $('.buyer-right-bottom.product-zhan li.picc').length;
			var piccArr = [];
			for (let i=0; i < piccLen; i++) {
				var piccArrItem = $('.buyer-right-bottom.product-zhan li.picc').eq(i).find('img').attr('src');
				piccArr.push({"image_url": piccArrItem});
			}
			
			//产品详情的信息
			var arrEditor = [],
				details;//产品详情
	        arrEditor.push(UE.getEditor('editor').getContent());
	        details = arrEditor.join("\n");
			
			//上传的参数
			var publishObj = {
				'catagory': catagory,
				'pname': pname,
				'title': title,
				'keyword': keyword,
				'sku_code': sku_code,
				'sku_id': pro_id,
				'spec': spec,
				'deng_ji': deng_ji,
				'pin_ban': pin_ban,
				'han_shui_lv': han_shui_lv,
				'gan_zao': gan_zao,
				'yong_tu': yong_tu,
				'parameters': [],
				'is_manage_kc': is_manage_kc,
				'unit': unit,
				'kc_ammount': parseFloat(kc_ammount),
				'min_qd': parseFloat(min_qd),
				'is_yang_pin': is_yang_pin,
				'price': parseFloat(price),
				'is_yj': is_yj,
				'fee': parseFloat(fee),
				'province': province,
				'city': city,
				'district': district,
				'product_images': piccArr,
				'details': details
			};
			
			if(lockKey == 0) {
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.alert('库存量没有填写', {'title': false,'closeBtn': 0});
						return false;
					}else if (!/^[0-9]*$/.test(kc_ammount)) {
						layer.alert('库存量填写格式不正确', {'title': false,'closeBtn': 0});
						return false;
					}
					panduan();
				}else{
					panduan();
				}
			} else {
				//自定义参数的信息
				for(let i = 0; i < lockKey; i++) {
					if($('#argue-name-' + i)) {
						//console.log(i);
						arr[2 * i] = $('#argue-name-' + i).val();
						arr[2 * i + 1] = $('#argue-value-' + i).val();
					}
				}
				brr = [];//自定义参数的数据
				for(let i = 0; i < arr.length; i++) {
					if(typeof arr[i] != 'undefined') {
						brr.push(arr[i]);
					}
				}
				
				//自定义参数的信息
				var parameters = [],
					paraObj = {};
				for (let i=0; i<brr.length; i+=2) {
					paraObj = {};
					paraObj['para_name'] = brr[i];
					paraObj['para_value'] = brr[i+1];
					parameters.push(paraObj);
				}
				publishObj.parameters = parameters;
				if(is_manage_kc == 1) {
					if('' == kc_ammount) {
						layer.msg('库存量没有填写', {'title': false,'closeBtn': 0});
						return false;
					}else if (!/^[0-9]*$/.test(kc_ammount)) {
						layer.alert('库存量填写格式不正确', {'title': false,'closeBtn': 0});
						return false;
					}
					panduan();
				}else{
					panduan();
				}
			}
			
			//判断方法
			function panduan(){
				if('' == title.trim()) {
					layer.alert('标题没有填写或者不能有空格', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == keyword.trim()) {
					layer.alert('关键字没有填写或者不能有空格', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == spec) {
					layer.alert('规格没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == deng_ji) {
					layer.alert('产品等级没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == pin_ban) {
					layer.alert('拼版没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == han_shui_lv) {
					layer.alert('含水率没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == gan_zao) {
					layer.alert('干燥方式没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == yong_tu) {
					layer.alert('用途没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == min_qd) {
					layer.alert('起订量没有填写', {'title': false,'closeBtn': 0});
					return false;
				} else if(!/^[0-9]*$/.test(min_qd)) {
					layer.alert('起订量填写格式不正确', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == price) {
					layer.alert('价格没有填写', {'title': false,'closeBtn': 0});
					return false;
				} else if(!/^((0|([1-9]\d*))(\.\d{1,2})?)?$/.test(price)) {
					layer.alert('价格填写格式不正确', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == fee) {
					layer.alert('运费没有填写', {'title': false,'closeBtn': 0});
					return false;
				} else if(!/^((0|([1-9]\d*))(\.\d{1,2})?)?$/.test(fee)) {
					layer.alert('运费填写格式不正确', {'title': false,'closeBtn': 0});
					return false;
				} else if('省份' == province) {
					layer.alert('省份没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('请选择' == city) {
					layer.alert('城市没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if('请选择' == district) {
					layer.alert('区/县没有选择', {'title': false,'closeBtn': 0});
					return false;
				} else if(piccLen == 0) {
					layer.alert('没有上传产品图片', {'title': false,'closeBtn': 0});
					return false;
				} else if('' == details) {
					layer.alert('产品详情没有填写', {'title': false,'closeBtn': 0});
					return false;
				}
				
				//发送数据到后台
				$.ajax({
					type: "post",
					url: api+"/api/FB_MIANDIBAN?access_token="+ access_token +"&user_id="+ user_id,
					async: true,
					data: JSON.stringify(publishObj),
					dataType: 'json'
				}).then(function(publishData){
					//console.log(JSON.stringify(publishObj));
					if (publishData.err_code == 0) {						
						layer.alert('发布成功', {'title': false,'closeBtn': 0}, function(){
							window.location.href = 'seller-pro-dai.html';
						});
					}else{
						layer.alert(publishData.msg, {'title': false,'closeBtn': 0});
					}
				});
			}
			
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(4).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
		
		//将中文逗号转换成英文逗号
		function changeDouHao(str){
			str=str.replace(/，/ig,',');
			return str;
		}
	});
});