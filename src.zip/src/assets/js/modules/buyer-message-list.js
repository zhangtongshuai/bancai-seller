require(['../common/common'],function(c){
    require(['jquery','template','md5','cookie','layui','slider','base','pager'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
        /**
         * 交互效果
         */
//      layui.use(['layer','element', 'form'], function(){
//          var layer = layui.layer;
            var user_id = $.cookie('user_id'),
                access_token = $.cookie('access_token');

            // var user_id = 1000000003,
            //     access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
            msglist(0,'');

            $('.header-top-box h2').eq(1).find('a').addClass("h2aline");
            $('.layui-tab-title li:nth-of-type(1)').addClass("layui-this");
            $('.layui-tab-item ol li:nth-of-type(1)').addClass("messagenow");
            //第二层选项卡
            $(".layui-tab-item ol li").click(function(){
                var index=$(".layui-tab-item ol li").index(this)
                $(this).addClass("messagenow").siblings().removeClass("messagenow")
                $(".layui-tab-item .message_list").eq(index).addClass("message_list_show").siblings().removeClass("message_list_show")
            });

            //全部消息时的锁
            //获取消息列表
            $('.layui-tab-title li').on('click', function(){
                var status1 = $(this).data().status;
                $('.now_status').html(status1);
            });
            $('.layui-tab-title li:nth-of-type(1)').click( function(){
                var msg_type2 =$(".now_type").html();
                msglist(0,msg_type2);
            });
            $('.layui-tab-title li:nth-of-type(2)').click( function(){
                var msg_type2 =$(".now_type").html();
                msglist(1,msg_type2);
            });
            $('.layui-tab-item ol li').click( function(){
                var msg_type1 = $(this).data().msg_type;
                $('.now_type').html(msg_type1);
                var status2=$(".now_status").html();
                var msg_type2 =$(".now_type").html();
                msglist(status2,msg_type2);
            });
            function msglist(status,msg_type){
                //init
                $(function () {
                    searchFilter(1);
                });
                function searchFilter(pageindex){
                    var pageNo = getParameter('pageIndex');
                    if (!pageNo) {
                        pageNo = pageindex;
                    }
                    //获取收到的消息
                        $.ajax({
                            type: 'get',
                            url: api + '/api/message_list?access_token='+access_token+'&user_id='+user_id+'&status='+ status+'&msg_type='+msg_type+'&page_no='+pageNo,
                            dataType: 'json',
                            contentType: "application/json; charset=utf-8",
                            success:function(r){
                                //console.log(r);
                                var count = parseInt(r.data.record_total);
                                var totalPage = parseInt(r.data.page_total);
                                var count2 = parseInt(r.data.record_total);
                                //console.log(count)
                                if (count == 0) {
                                    $('#message_platform_list').hide();
                                    $('#no-data').show();
                                    $('#kkpager').hide();
                                }else{
                                    $('#message_platform_list').show();
                                    $('#no-data').hide();
                                    $('#kkpager').show();
                                    $('#message_platform_list').html('');
                                    var data = r.data.list;
                                    var html = template('tpl_message_platform_list', data);
                                    $('#message_platform_list').html(html);

                                    //消息数量显示
                                    var status3 = $(".now_status").html();
                                    if(status3 == 0){
                                        $(".unread_title").click(function () {
                                            var urmsg = window.localStorage.getItem("unread_msg");
                                            var urdmsg = parseInt(urmsg);
                                            urdmsg--;
                                            window.localStorage.setItem("unread_msg",urdmsg);
                                        });

                                        //删除消息按钮
                                        $(".icon-garbagecan").click(function (count) {
                                            //console.log($(this))
                                            var msglifo = $(this);
                                            var msg_id1 = msglifo.parents(".message_list_info").find('strong').html();
                                            var msg_id = parseInt(msg_id1);
                                            layer.open({
                                                content: '您确定要删除本条消息？'
                                                ,btn: ['是', '否']
                                                ,yes: function(offerData){
                                                    //alert(333);
                                                    //console.log(pur_id);
                                                    $.ajax({
                                                        type: 'delete',
                                                        url : api +  '/api/message_detail?access_token='+access_token+'&user_id='+user_id+'&msg_id='+msg_id,
                                                        dataType: 'json',
                                                        contentType: "application/json; charset=utf-8",
                                                        success:function(finishData){
                                                            //console.log(finishData);
                                                            msglifo.parents('.message_info').remove();
                                                            layer.alert('删除成功', {icon: 1});
                                                            var urmsg2 = window.localStorage.getItem("unread_msg");
                                                            var urdmsg2 = parseInt(urmsg2);
                                                            urdmsg2--;
                                                            window.localStorage.setItem("unread_msg",urdmsg2);
                                                            count2--;
                                                            //console.log(count2)
                                                            if(count2==0){
                                                                $('#message_platform_list').hide();
                                                                $('#no-data').show();
                                                                $('#kkpager').hide();
                                                            }
                                                        }
                                                    });
                                                },btn2: function(){
                                                    //按钮【按钮二】的回调
                                                }
                                                ,cancel: function(){
                                                    //右上角关闭回调
                                                }
                                            });
                                        });
                                    }else{
                                        //删除消息按钮
                                        $(".icon-garbagecan").click(function (count) {
                                            //console.log($(this))
                                            var msglifo = $(this);
                                            var msg_id1 = msglifo.parents(".message_list_info").find('strong').html();
                                            var msg_id = parseInt(msg_id1);
                                            layer.open({
                                                content: '您确定要删除本条消息？'
                                                ,btn: ['是', '否']
                                                ,yes: function(offerData){
                                                    //alert(333);
                                                    //console.log(pur_id);
                                                    $.ajax({
                                                        type: 'delete',
                                                        url : api +  '/api/message_detail?access_token='+access_token+'&user_id='+user_id+'&msg_id='+msg_id,
                                                        dataType: 'json',
                                                        contentType: "application/json; charset=utf-8",
                                                        success:function(finishData){
                                                            //console.log(msglifo.parents('.message_info'));
                                                            msglifo.parents('.message_info').remove();
                                                            layer.alert('删除成功', {icon: 1});
                                                            count2--;
                                                            //console.log(count2)
                                                            if(count2==0){
                                                                $('#message_platform_list').hide();
                                                                $('#no-data').show();
                                                                $('#kkpager').hide();
                                                            }
                                                        }
                                                    });
                                                },btn2: function(){
                                                    //按钮【按钮二】的回调
                                                }
                                                ,cancel: function(){
                                                    //右上角关闭回调
                                                }
                                            });
                                        });
                                    }

                                    //生成分页
                                    kkpager.generPageHtml({
                                        pno: pageNo,
                                        //总页码
                                        total : totalPage,
                                        //总数据条数
                                        totalRecords : count,
                                        mode : 'click',
                                        click : function(n){
                                            this.selectPage(pageNo);
                                            searchPage(n);
                                            return false;
                                        }
                                    },true);
                                }
                            }
                        });
                }
                //ajax翻页
                function searchPage(n) {
                    searchFilter(n);
                }
                //分页数量
                function getParameter(name) {
                    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
                    var r = window.location.search.substr(1).match(reg);
                    if (r!=null) return unescape(r[2]); return null;
                }
            }
//      });
    });
});