var user_type = Cookies.get('user_type');
if(typeof user_type == 'undefined' || user_type == 0){
	window.location.href = 'http://www.bancai.com/login_seller.html'
}
