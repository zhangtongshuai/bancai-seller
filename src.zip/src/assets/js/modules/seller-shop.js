require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
    	//进入页面时获得的数据
		$.ajax({
			type: "get",
			url: api+"/api/shop_main?access_token="+access_token+"&user_id="+user_id,
			async:true,
			dataType: 'json'
		}).then(function(shopinfoData){
			if(shopinfoData.err_code != 0){
				layer.alert(shopinfoData.msg, {'title': false,'closeBtn': 0});
				return false;
			}
			if('' == shopinfoData.data.status || '0' == shopinfoData.data.status || null == shopinfoData.data.status) {
				//没开通的时候店铺名称设置为企业名称
				$('#shop-name').val(shopinfoData.data.shop_name);
				//点击修改输入框获取焦点
				$('.buyer-right-bottom .shop-xiugai').on('click', function(){
					$('#shop-name').removeAttr('disabled').focus();
				});
				//点击开通按钮
		    	$('#kai-tong').on("click", function(){
		    		//类型选择
		    		var leixing = [],
		    			leixinglen = $('.layui-form:eq(0) input').length;
		    		for (let i=0; i<leixinglen; i++) {
		    			var itemed = $('.layui-form:eq(0) div').eq(i).attr('class');
		    			if (itemed.indexOf('layui-form-checked') !== -1) {
		    				leixing.push($('.layui-form:eq(0) div').eq(i).find('span').text());
		    			}
		    		}
		    		var shichang = [],
		    			shichanglen = $('.layui-form:eq(1) input').length;
		    		for (let i=0; i<shichanglen; i++) {
		    			var itemed = $('.layui-form:eq(1) div').eq(i).attr('class');
		    			if (itemed.indexOf('layui-form-checked') !== -1) {
		    				shichang.push($('.layui-form:eq(1) div').eq(i).find('span').text());
		    			}
		    		}
		    		
		    		//获取填写的信息
		    		var shop_name = $('#shop-name').val(),
		    			shop_leixing = leixing.join(','),
		    			markets = shichang.join(','),
		    			shop_phone = $('#shop-phone').val(),
		    			qq = $('#shop-qq').val(),
		    			shop_logo = $('.logo-zhan img').attr('src'),
		    			jiao_jie = $('textarea').val();
		    			
		    		var kaitongObj = {
		    			shop_name: shop_name,
		    			catagories: shop_leixing,
		    			logo: shop_logo,
		    			introduction: jiao_jie,
		    			markets: markets,
		    			phone_no: shop_phone,
		    			qq: qq
		    		};
		    		
		    		var regPhone = /(^(\d{3,4}-)+\d{7,8}$)|(^1[3-9][0-9]{9}$)/;//手机号和固定电话
		    		
		    		if ('' == shop_name) {
		    			layer.alert('店铺名称没有填写', {'title': false,'closeBtn': 0});
		    		}else if (shop_name.indexOf(' ') >= 0) {
		    			layer.alert('店铺名称不能有空格', {'title': false,'closeBtn': 0});
		    		}else if ('' == shop_leixing) {
		    			layer.alert('经营品类没有选择', {'title': false,'closeBtn': 0});
		    		}else if (shop_logo == '') {
		    			layer.alert('企业logo没有选择', {'title': false,'closeBtn': 0});
		    		}else if ('' == shop_phone) {
		    			layer.alert('联系电话不能为空', {'title': false,'closeBtn': 0});
		    		}else if (!regPhone.test(shop_phone)) {
		    			layer.alert('联系电话格式不正确', {'title': false,'closeBtn': 0});
		    		}else if ('' == qq) {
		    			layer.alert('QQ不能为空', {'title': false,'closeBtn': 0});
		    		}else if (!/^\d{5,15}$/.test(qq)) {
		    			layer.alert('QQ格式不正确', {'title': false,'closeBtn': 0});
		    		}else if ('' == markets) {
		    			layer.alert('主要市场没有选择', {'title': false,'closeBtn': 0});
		    		}else if ('' == jiao_jie.trim()) {
		    			layer.alert('店铺介绍不能为空', {'title': false,'closeBtn': 0});
		    		}else{
		    			$.ajax({
		    				type: 'post',
		    				url: api+"/api/shop_main?access_token="+access_token+"&user_id="+user_id,
		    				data: JSON.stringify(kaitongObj),
		    				dataType: 'json'
		    			}).then(function(kaiData){
							if (kaiData.err_code == 0) {
								//获取shopid
								$.ajax({
									type: 'get',
									url: api + '/api/shopid?access_token='+access_token+'&user_id='+user_id,
									dataType: 'json'
								}).then(function(certData){
									if (certData.err_code == 0) {		
										$.cookie('shop_id', certData.data);
									}else{
										layer.alert(certData.msg, {'title': false,'closeBtn': 0});
									}
								});
								layer.alert('恭喜您，您的店铺【'+shop_name+'】已开通成功', {'title': false,'closeBtn': 0}, function(){
									window.location.reload();
								});
								$(this).off('click').removeClass('layui-btn-danger').addClass('layui-btn-disabled');
							}else{
								layer.alert(kaiData.msg, {'title': false, 'closeBtn': 0});
							}
		    			});
		    		}
		    	});
			}else{
				$('#kai-tong').off('click').removeClass('layui-btn-danger').addClass('layui-btn-disabled');
				//修改字眼隐藏(无法修改店铺名称)
				$('.buyer-right-bottom .shop-xiugai').hide();
				//店铺名称展示
				$('#shop-name').val(shopinfoData.data.shop_name);
				//店铺经营品类
				var leixinglen = $('.layui-form:eq(0) input').length;
				for (let i=0; i<leixinglen; i++) {
					var tx = $('.layui-form:eq(0) div').eq(i).find('span').text();
					if (shopinfoData.data.catagories.indexOf(tx) !== -1) {
						$('.layui-form:eq(0) div').eq(i).addClass('layui-form-checked');
					}
				}
				//主要市场
				var shichanglen = $('.layui-form:eq(1) input').length;
				for (let i=0; i<shichanglen; i++) {
					var tx = $('.layui-form:eq(1) div').eq(i).find('span').text();
					if (shopinfoData.data.markets.indexOf(tx) !== -1) {
						$('.layui-form:eq(1) div').eq(i).addClass('layui-form-checked');
					}
				}
				//logo展示
				$('#logo-up').hide();
				$('#logocom').hide();
				$('#logocom+span').hide();
				$('.logo-zhan').show();
				$('.logo-zhan img').attr('src', shopinfoData.data.logo);
				//联系人
				$('#shop-phone').val(shopinfoData.data.phone_no).attr({'disabled': true});
				//QQ
				$('#shop-qq').val(shopinfoData.data.qq).attr({'disabled': true});
				//公司介绍
				$('textarea').val(shopinfoData.data.introduction).attr({'disabled': true});
				//开通过隐藏
    			$('.kai-tong-guo').show();
    			$('.kai-tong-guo').text($('.kai-tong-guo').text()+'【'+shopinfoData.data.shop_name+'】');
    			//logo叉号隐藏
    			$('.logo-zhan .cha').hide();
			}
		});
		
		//logo上传
    	$('#logocom').on('change', function(event) {
			//获取图片的大小
			var fileSize = this.files[0].size;
			//对于图片的大小进行比较
			if(fileSize >  500 * 1024) {
				layer.alert("上传图片大小不能超过500K", {'title': false,'closeBtn': 0});
				return false;
			} else {
				var file = $(this)[0].files[0];
				if(!/image\/\w+/.test(file.type)){   
					alert("请确保文件为图像类型"); 
					return false; 
				}
				r = new FileReader();  //本地预览
				r.onload = function(){
					var pictureFile = r.result;
					//没有上传完之前input隐藏
					$('#logo-up').hide();
					$('#logocom').hide();
					$('#logocom+span').hide();
					$('.logo-zhan').show();
					
					var product_commit_obj = {
						user_id: user_id,
						access_token: access_token,
						simage: pictureFile
					};
					
					$.ajax({
						type: "post",
						url: api+"/api/Upload_Image",
						async:true,
						data: JSON.stringify(product_commit_obj),
						dataType: 'json'
					}).then(function(picUploadData){
						if(picUploadData.err_code == 0){
							$('.logo-zhan img').attr('src', picUploadData.data.image_url);
						}else{
							layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});
						}
					});
				}
				r.readAsDataURL(file);    //Base64
				
				
//				var imageUrl = getObjectURL($(this)[0].files[0]);
//				var index = $(this)[0].files[0].name.lastIndexOf('.');
//				var imagethis = $(this)[0].files[0].name.slice(index+1);
//				if(imagethis == 'jpg'){
//					imagethis = 'jpeg';
//				}
//				convertImgToBase64(imageUrl, function(base64Img) {
//					pictureFile = base64Img;
//					
//					//没有上传完之前input隐藏
//					$('#logo-up').hide();
//					$('#logocom').hide();
//					$('#logocom+span').hide();
//					$('.logo-zhan').show();
//					
//					var product_commit_obj = {
//						user_id: user_id,
//						access_token: access_token,
//						simage: pictureFile
//					};
//					
//					$.ajax({
//						type: "post",
//						url: api+"/api/Upload_Image",
//						async:true,
//						data: JSON.stringify(product_commit_obj),
//						dataType: 'json'
//					}).then(function(picUploadData){
//						if(picUploadData.err_code == 0){
//							$('.logo-zhan img').attr('src', picUploadData.data.image_url);
//						}else{
//							layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});
//						}
//					});
//				});
//				
//				event.preventDefault();
			}
		});
		$('.logo-zhan').on('click', 'i', function() {
			$(this).find('img').attr('src', '');
			$('#logo-up').show();
			$('#logocom').show();
			$('#logocom+span').show();
			$('.logo-zhan').hide();
		});
		
		
    	//上传图片的方法
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 1;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}
		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		}
    	
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(6).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
    });
});