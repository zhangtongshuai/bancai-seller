require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		var oldData;//表示原来的数据
		
		//获取联系人信息
		$.ajax({
			type: 'get',
			url: api + '/api/Contacts?user_id='+user_id+'&access_token='+access_token,
			dataType: 'json'
		}).then(function(certData){
			if (certData.err_code == 0) {
				if (certData.data != null) {
					oldData = certData.data;
					$('.cert-xiu-gai').show();
					$('.cert-bao-cun').hide();
					$("#gai-per").val(certData.data.contacts);
					$("#gai-phone").val(certData.data.phone_no);
					$("#gai-email").val(certData.data.email);
				}else{
					$('.cert-bao-cun').show();
					$('.cert-xiu-gai').hide();
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		
		/*手机号的正则*/
		var regPhone = /(^((0\d{3}|(400|800))-)?\d{7,8}$)|(^1[3-9][0-9]{9}$)/;
		/*电子邮箱的正则*/
		var regEmail = /[_a-z\d\-\./]+@[_a-z\d\-]+(\.[_a-z\d\-]+)*(\.(info|biz|com|edu|gov|net|am|bz|cn|cx|hk|jp|tw|vc|vn))$/;
		
		
		/*点击保存按钮*/
		$('.cert-bao-cun div').eq(3).find('span:eq(0)').on('click', function(){
			var containsObj = {
				user_id: user_id,
				access_token: access_token,
				contacts: $("#cun-per").val(),
				phone_no: $("#cun-phone").val(),
				email: $("#cun-email").val()
			};
			changeContains(containsObj);
		});
		/*点击取消按钮*/
		$('.cert-bao-cun div').eq(3).find('span:eq(1)').on('click', function(){
			$("#cun-per").val('');
			$("#cun-phone").val('');
			$("#cun-email").val('');
		});
		/*点击修改按钮*/
		$('.cert-xiu-gai div').eq(3).find('span:eq(0)').on('click', function(){
			$(this).hide().siblings().show();
			$('.cert-xiu-gai input').removeAttr('disabled').css({'border-color': '#ddd'});
		});
		//点击保存
		$('.cert-xiu-gai div').eq(3).find('span:eq(1)').on('click', function(){
			var containsObj = {
				user_id: user_id,
				access_token: access_token,
				contacts: $("#gai-per").val(),
				phone_no: $("#gai-phone").val(),
				email: $("#gai-email").val()
			};
			changeContains(containsObj);
		});
		//点击取消
		$('.cert-xiu-gai div').eq(3).find('span:eq(2)').on('click', function(){
			$('.cert-xiu-gai div').eq(3).find('span').hide();
			$('.cert-xiu-gai div').eq(3).find('span:eq(0)').show();
			$('.cert-xiu-gai input').attr('disabled', true).css({'border-color': 'transparent'});
		});
		
		
		function changeContains(containsObj){
			//console.log(containsObj.contacts);
			if (containsObj.contacts == "") {
				layer.alert('联系人信息不能为空', {'title': false,'closeBtn': 0});
				return false;
			}else if(containsObj.contacts.indexOf(' ') >= 0){
				layer.alert('联系人信息不能有空格', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.phone_no == "" || !regPhone.test(containsObj.phone_no)) {
				layer.alert('电话格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}else if (containsObj.email == "" || !regEmail.test(containsObj.email)) {
				layer.alert('邮箱格式不正确', {'title': false,'closeBtn': 0});
				return false;
			}
			
			$.ajax({
				type: "post",
				url: api + "/api/Contacts",
				async:true,
				data: JSON.stringify(containsObj),
				dataType: "json"
			}).then(function(changmsg){
				if(changmsg.err_code == 0){
					window.location.reload();
				}else{
					layer.alert(changmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(3)").find("a").css({"color": "#ff3c00"});
    });
});