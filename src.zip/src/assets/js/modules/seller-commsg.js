require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
    	
    	$.get("include/company.html", function(companymsgData){
    	 	var render = template.compile(companymsgData);
			//获取公司信息
			$.ajax({
				type: 'get',
				url: api + '/api/Ent_Info?access_token='+access_token+'&user_id='+user_id+'&ent_name=',
				dataType: 'json'
			}).then(function(companyData){
				if (companyData.err_code == 0) {
					if (companyData.data != null) {
						var html = render(companyData);
						$("#companymsg").html(html);
					}
				}else{
					layer.alert(companyData.msg, {'title': false,'closeBtn': 0});
				}
			});
    	});
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(5)").find("a").css({"color": "#ff3c00"});
    });
});