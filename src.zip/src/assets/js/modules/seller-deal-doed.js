require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','pager','slider','base'], function($,template,md5,layui,cookie) {

		/**
		 * 数据渲染
		 */
		template.defaults.imports.phoneStar = function(obj){
			var arr = obj.split('');
			for (let i=0; i<arr.length; i++) {
				if (i<7 && i>2) {
					arr[i] = '*';
				}
			}
			return arr.join('');
		}
		
		var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		//init
	    $(function () {
	        searchFilter(1)
	    });
	    
		function searchFilter(pageindex){
			var pageNo = getParameter('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
	        }
			$.ajax({
				url: api+"/api/order_finish_s?access_token="+access_token+"&user_id="+user_id+"&page_no="+pageNo,
				type: 'get',
				dataType: 'json',
				success:function(result){
					//console.log(result);
					if (result.err_code != 0) {
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
						return false;
					}
					var count = parseInt(result.data.record_count);
                    var totalPage = parseInt(result.data.page_total);
                    if (count == 0) {
                    	$('#no-data').show();
                    }else{
                    	var shop_vip = localStorage.getItem('shop_vip');
						if(shop_vip == 1){
							var html = template('order-vip', result.data.list);
							$('#order-zhan').html(html);
						}else{
							var html = template('order', result.data.list);
							$('#order-zhan').html(html);
						}
                    	
	                    
						//生成分页
						kkpager.generPageHtml({
							pno: pageNo,
							//总页码
							total : totalPage,
							//总数据条数
							totalRecords : count,
							mode : 'click',
							click : function(n){
							    this.selectPage(pageNo);
			                    searchPage(n);
			                    return false;
							}
						},true);
                    }
					
				},
				error: function () {
                    layer.msg('网络请求失败，请刷新后重试！');
                }	
			})
		}
		//ajax翻页
	    function searchPage(n) {
	        searchFilter(n);
	    }
		//分页数量
		function getParameter(name) { 
			var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); 
			var r = window.location.search.substr(1).match(reg); 
			if (r!=null) return unescape(r[2]); return null;
		}
		/**
		 * 交互效果
		 */
		/*点击开票信息按钮*/
		$('#order-zhan').on('click', '.fpzi', function(){
			$(this).parents('.seller-bottom').children('.fpmsg').css({'display': 'block'});
		});
		/*点击发票信息的叉号*/
		$('#order-zhan').on('click', 'i.fpcha', function(){
			$(this).parents('.fpmsg').hide();
		});
		
		/*点击去评价按钮*/
		$('#order-zhan').on('click', '.left5', function(){
			var danhao = $(this).parents('.seller-bottom').find('.seller-bottom-top span:eq(1) em').html();
			console.log(danhao);
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(3)").find("a").css({"color": "#ff3c00"});
	});
});