/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery','cookie'],function($,cookie){
       
    	/**
    	 * 公用效果
    	 */
		//获取用户信息
		var cookieMsg = $.cookie(),
			access_token = cookieMsg.access_token,
			user_id = cookieMsg.user_id;
		
		//卖家中心产品展示图片上传
		var picLiLen = 0,
			piccI = 0, //图片的顺序标示
			pictureFile; //图片base64信息
		$('#product-zhan-up').on('change', function(event) {
			//获取图片的大小
			var fileSize = this.files[0].size;
			//图片顺序改变
			piccI ++;
			//对于图片的大小进行比较
			if(fileSize > 1 * 1024 * 1024) {
				layer.alert("上传图片大小不能超过1M", {'title': false,'closeBtn': 0});
				return false;
			} else {
				var file = $(this)[0].files[0];
				if(!/image\/\w+/.test(file.type)){   
					alert("请确保文件为图像类型"); 
					return false; 
				}
				r = new FileReader();  //本地预览
				r.onload = function(){
					pictureFile = r.result;
					
					$('.buyer-right-bottom.product-zhan ul').prepend('<li class="picc picc'+piccI+'">' +
						'<div class="layui-progress"><div class="layui-progress-bar" lay-percent="0%"></div></div>'
																	+ '</li>');
					
					
					//上传图片时加载进度
					var oldProgressNum = [0, 0, 0, 0, 0, 0];//进度初始化的数
					var timerProgress = setInterval(function(){
						var progressNum = Math.ceil(Math.random()*3);
						oldProgressNum[piccI] += progressNum;
						if (oldProgressNum[piccI] >= 85) {
							clearInterval(timerProgress);
							$('.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
							$('.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
							return false;
						}
						$('.picc'+piccI+' .layui-progress div').attr('lay-percent', (oldProgressNum[piccI] + progressNum)+'%');
						$('.picc'+piccI+' .layui-progress div').css({'width': (oldProgressNum[piccI] + progressNum)+'%'});
					}, 100);
					//没有上传完之前input隐藏
					$(this).hide();
					
					var product_commit_obj = {
						user_id: user_id,
						access_token: access_token,
						simage: pictureFile
					};
					$.ajax({
						type: "post",
						url: api+"/api/Upload_Image",
						async:true,
						data: JSON.stringify(product_commit_obj),
						dataType: 'json'
					}).then(function(picUploadData){
						if(picUploadData.err_code == 0){
							$(this).show();
							$('.picc' + piccI).empty();
							$('.picc' + piccI).append('<img src="'+picUploadData.data.image_url+'" /><div class="cha"><i class="iconfont icon-cross"></i></div>');
						}else{
							layer.alert(picUploadData.msg, {'title': false,'closeBtn': 0});
						}
					});
					
					picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
					if(picLiLen == 6) {
						$('.updata-box').hide();
					}
				}
				r.readAsDataURL(file);    //Base64
			}
		});
		$('.buyer-right-bottom.product-zhan ul').on('click', 'i', function() {
			$(this).parents('li.picc').remove();
			picLiLen = $('.buyer-right-bottom.product-zhan ul li').length;
			if(picLiLen <= 5) {
				$('.updata-box').show();
			}
		});
		
		//点击自定义规格按钮后
		$('#word-zi-ding-yi').on('click', function(){
			$('#zi-ding-yi-spec').show();
			$('#spec').next().find('input').val('');
		});
		$('#zi-ding-yi-spec span.layui-btn-danger').on('click', function(){
			var chang = $('#chang-du').val(),
	        	kuan = $('#kuan-du').val(),
	        	gao = $('#gao-du').val();
	        var reg = /^((0|([1-9]\d*))(\.\d{1,2})?)?$/;//输入的数字格式判断
        	if('' == chang){
        		layer.alert('长度没有填写', {'title': false,'closeBtn': 0});
        		return false;
        	}else if(!reg.test(chang)){
        		layer.alert('长度格式不正确', {'title': false,'closeBtn': 0});
        		return false;
        	}else if('' == kuan){
        		layer.alert('宽度没有填写', {'title': false,'closeBtn': 0});
        		return false;
        	}else if(!reg.test(kuan)){
        		layer.alert('宽度格式不正确', {'title': false,'closeBtn': 0});
        		return false;
        	}else if('' == gao){
        		layer.alert('高度没有填写', {'title': false,'closeBtn': 0});
        		return false;
        	}else if(!reg.test(gao)){
        		layer.alert('高度格式不正确', {'title': false,'closeBtn': 0});
        		return false;
        	}else{
        		var spec = chang+'*'+kuan+'*'+gao;
        		$('#spec').next().find('input').val(spec);
        	}
		});
		$('#zi-ding-yi-spec span.layui-btn-primary').on('click', function(){
			$('#zi-ding-yi-spec').hide();
			$('#word-zi-ding-yi').show();
		});
		
		//地区
		var province = $("#province"),
			city = $("#city"),
			town = $("#town");
		for(var i = 0; i < provinceList.length; i++){
			addEle(province, provinceList[i].name);
		}

		function addEle(ele, value){
			var optionStr = "";
			optionStr = "<option value=" + value + ">" + value + "</option>";
			ele.append(optionStr);
		}

		function removeEle(ele){
			ele.find("option").remove();
			var optionStar = "<option value=" + "请选择" + ">" + "请选择" + "</option>";
			ele.append(optionStar);
		}
		var provinceText, cityText, cityItem;
		province.on("change", function() {
			provinceText = $(this).val();
			$("#province").attr("val", provinceText);
			$.each(provinceList, function(i, item) {
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			removeEle(city);
			removeEle(town);
			$.each(provinceList[cityItem].cityList, function(i, item){
				addEle(city, item.name);
			});
		});
		city.on("change", function(){
			cityText = $(this).val();
			$("#city").attr("val", cityText);
			removeEle(town);
			$.each(provinceList, function(i, item){
				if(provinceText == item.name){
					cityItem = i;
					return cityItem
				}
			});
			$.each(provinceList[cityItem].cityList, function(i, item){
				if(cityText == item.name){
					for(var n = 0; n < item.areaList.length; n++){
						addEle(town, item.areaList[n])
					}
				}
			});
		});
		//获取默认发货地点
		$.ajax({
			type: "get",
			url: api+"/api/fh_address",
			async:true,
			data: {
				'access_token': access_token,
				'user_id': user_id
			},
			dataType: 'json'
		}).then(function(fhData){
			if(fhData.err_code == 0){
				if (cookieMsg.different != 1) {
					
					$('#province').val(fhData.data.province);
					$('#city').val(fhData.data.city);
					$('#town').val(fhData.data.district);
				}
			}else{
				layer.alert(fhData.msg, {'title': false,'closeBtn': 0});	
			}
		});
		
		//点击地址后
		$('#province,#city,#town').on('click', function(){
			$('#province option:eq(0)').text('请选择');
				$('#city option:eq(0)').text('请选择');
				$('#town option:eq(0)').text('请选择');
		});

		//已进入页面先禁用
		if (cookieMsg.different != 1) {
			$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val('0');
			$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').attr('disabled', true);
		}
		//库存量为0
		$('.buyer-right-bottom.order .layui-form-item').eq(0).find('.layui-input-block').on('click', function(){
			var is_kc = $('.buyer-right-bottom.order .layui-input-block').eq(0).find('input[type=radio]:checked').val();
			if (is_kc == 0) {
				$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val('0');
				$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').attr('disabled', true);
			}else{
				$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').val('');
				$('.buyer-right-bottom.order .layui-input-block').eq(2).find('input').removeAttr('disabled');
			}
		});
    });
});