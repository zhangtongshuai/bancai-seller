require(['../common/common'],function(c){
    require(['jquery','template','md5','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
        var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
    });
});