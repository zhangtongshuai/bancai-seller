require(['../common/common'], function(c) {
	require(['jquery','template','md5','layui','cookie','slider','base'], function($,template,md5,layui,cookie) {

		/**
		 * 数据渲染
		 */
		template.defaults.imports.phoneStar = function(obj){
			var arr = obj.split('');
			for (let i=0; i<arr.length; i++) {
				if (i<7 && i>2) {
					arr[i] = '*';
				}
			}
			return arr.join('');
		}
		
		var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
		
		$.ajax({
			type: "get",
			url: api+"/api/order_pay_s?access_token="+access_token+"&user_id="+user_id,
			async:true,
			dataType: 'json'
		}).then(function(noData){
			//console.log(noData);
			if (noData.err_code == 0) {
				if (noData.data != '') {
					var shop_vip = localStorage.getItem('shop_vip');
					if(shop_vip == 1){
						var html = template('order-vip', noData.data);
						$('#order-zhan').html(html);
					}else{
						var html = template('order', noData.data);
						$('#order-zhan').html(html);
					}
					localStorage.setItem('order_process', noData.data.length);
				}else{
					$('#no-data').show();
				}
			}else{
				layer.alert(noData.msg, {'title': false,'closeBtn': 0});
			}
			
		});
				
		/**
		 * 交互效果
		 */
		/*点击开票信息按钮*/
		$('#order-zhan').on('click', '.fpzi', function(){
			$(this).parents('.seller-bottom').children('.fpmsg').css({'display': 'block'});
		});
		/*点击发票信息的叉号*/
		$('#order-zhan').on('click', 'i.fpcha', function(){
			$(this).parents('.fpmsg').hide();
		});
		
		
		/*点击确认按钮*/
		$('#order-zhan').on('click', '.left5', function(){
			var that = this;
			var zi = $(this).html();
			var danhao = $(this).parents('.seller-bottom').find('.seller-bottom-top span:eq(1) em').html();
			//console.log(danhao);
			var content = {"order_id": danhao};
			if (zi == '确认') {				
				$.ajax({
					type: "post",
					url: api+"/api/order_finish_seller?access_token="+access_token+"&user_id="+user_id,
					async:true,
					data: JSON.stringify(content),
					dataType: 'json'
				}).then(function(result){
					if (result.err_code == 0) {
						layer.alert('确认完成', {'title': false,'closeBtn': 0});
						$(that).html('去发货');
					}else{
						layer.alert(result.msg, {'title': false,'closeBtn': 0});
					}
				});
			}else if (zi == '去发货') {
				$.ajax({
					type: 'post',
					url: api+"/api/order_fh_seller?access_token="+access_token+"&user_id="+user_id,
					data: JSON.stringify(content),
					dataType: 'json'
				}).then(function(fh){
					if(fh.err_code == 0){
						layer.alert('发货成功', {'title': false,'closeBtn': 0});
						$(that).hide();
						$(that).parents('.seller-bottom-bottom').children('.bottom-left').html('等待买家确认收货');
					}else{
						layer.alert(fh.msg, {'title': false,'closeBtn': 0});
					}
				});
			}
		});
		/*点击查看付款凭证按钮*/
		$('#order-zhan').on('click', '.chapingzheng', function(){
			$(this).parents('.seller-bottom').find('.ping-zheng-zhan').show();
		});
		$('#order-zhan').on('click', '.ping-zheng-zhan', function(){
			$(this).hide();
		});

		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(2).find("dd:nth-of-type(2)").find("a").css({"color": "#ff3c00"});
	});
});