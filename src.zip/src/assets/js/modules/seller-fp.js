require(['../common/common'],function(c){
    require(['jquery','template','md5','layui','cookie','slider','base'],function($,template,md5){
        
    	/**
    	 * 数据渲染
    	 */
    	var user_id = $.cookie('user_id'),
			access_token = $.cookie('access_token');
	 	
		//默认是灰色的按钮并且没有点击事件
		$(".buyer-right-bottom button").css({'background-color': '#999'});
		//获取联系人信息
		$.ajax({
			type: 'get',
			url: api + "/api/invoice?access_token="+access_token+"&user_id="+user_id,
			dataType: 'json'
		}).then(function(certData){
			//console.log(certData);
			if (certData.err_code == 0) {
				if (certData.data != null) {
					$("#contains-btn").val(certData.data.title);
					$("#diff-btn").val(certData.data.credit_code);
					$("#address-btn").val(certData.data.register_address);
					$("#phone-btn").val(certData.data.register_phone);
					$("#open-btn").val(certData.data.bank);
					$("#bank-btn").val(certData.data.bank_account);
				}else{
					$("#contains-btn").focus();
				}
			}else{
				layer.alert(certData.msg, {'title': false,'closeBtn': 0});
			}
		});
		$("#contains-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#diff-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#address-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#phone-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#open-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		$("#bank-btn").on('input', function(){
			$(".buyer-right-bottom button").css({'background-color': '#ff3c00'});
		});
		
		$("#contains-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#diff-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#address-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#phone-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#open-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		$("#bank-btn").on('change', function(){
			$(".buyer-right-bottom button").on("click", function(){
				changeContains();
			});
		});
		
		var regPhone = /^1(3|4|5|7|8)\d{9}$/;
		var regNa = /^[A-Za-z0-9]+$/;
		
		function changeContains(){
			var containsObj = {
				title: $("#contains-btn").val(),
				credit_code: $("#diff-btn").val(),
				register_address: $("#address-btn").val(),
				register_phone: $("#phone-btn").val(),
				bank: $("#open-btn").val(),
				bank_account: $("#bank-btn").val()
			};
			//console.log(containsObj);
			if (containsObj.title.trim() == "") {
				$(".buyer-right-bottom > span").html("单位名称不能为空或有空格");
				$("#contains-btn").val('');
				$("#contains-btn").focus();
				return false;
			}else if (containsObj.credit_code.trim() == "") {
				$(".buyer-right-bottom > span").html("纳税人识别码不能为空");
				$("#diff-btn").val('');
				$("#diff-btn").focus();
				return false;
			}else if (!regNa.test(containsObj.credit_code)) {
				$(".buyer-right-bottom > span").html("纳税人识别码格式不正确");
				$("#diff-btn").focus();
				return false;
			}else if (containsObj.register_phone.trim() != '' && !regPhone.test(containsObj.register_phone)) {
				$(".buyer-right-bottom > span").html("注册电话格式不正确");
				$("#phone-btn").focus();
				return false;
			}else if (containsObj.bank_account.trim() != '' && !/^[\da-zA-Z]+$/.test(containsObj.bank_account)) {
				$(".buyer-right-bottom > span").html("银行账户格式不正确");
				$("#bank-btn").val('');
				$("#bank-btn").focus();
				return false;
			}
			
			$.ajax({
				type: "post",
				url: api + "/api/invoice?access_token="+access_token+"&user_id="+user_id,
				async:true,
				data: JSON.stringify(containsObj),
				dataType: "json"
			}).then(function(changmsg){
				//console.log(changmsg);
				if(changmsg.err_code == 0){
					window.location.reload();
				}else{
					layer.alert(changmsg.msg, {'title': false,'closeBtn': 0});
				}
			});
		}
    	/**
    	 * 交互效果
    	 */
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(9).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});